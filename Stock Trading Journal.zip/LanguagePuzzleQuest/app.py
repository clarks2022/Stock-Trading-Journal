import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
from utils.data_fetcher import DataFetcher
from utils.options_pricing import OptionsCalculator
from utils.risk_management import RiskManager
from database import init_db, get_database_service

# Page configuration
st.set_page_config(
    page_title="Stock Options Analysis & Risk Management",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize database
@st.cache_resource
def initialize_database():
    try:
        init_db()
        return True
    except Exception as e:
        st.error(f"Database initialization error: {str(e)}")
        return False

# Initialize session state
if 'portfolio' not in st.session_state:
    st.session_state.portfolio = []
if 'watchlist' not in st.session_state:
    st.session_state.watchlist = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'SPY']
if 'db_initialized' not in st.session_state:
    st.session_state.db_initialized = initialize_database()
if 'user_id' not in st.session_state:
    # Get or create default user
    try:
        with get_database_service() as db_service:
            user = db_service.get_or_create_user()
            st.session_state.user_id = user.id
    except Exception as e:
        st.session_state.user_id = None
        st.error(f"Database connection error: {str(e)}")

def main():
    st.title("📈 Stock Options Analysis & Risk Management")
    st.markdown("---")
    
    # Sidebar for symbol selection and basic controls
    with st.sidebar:
        st.header("🎯 Stock Selection")
        
        # Symbol input
        symbol = st.text_input("Enter Stock Symbol:", value="AAPL", key="main_symbol").upper()
        
        # Watchlist
        st.subheader("📋 Watchlist")
        for watch_symbol in st.session_state.watchlist:
            if st.button(watch_symbol, key=f"watch_{watch_symbol}"):
                symbol = watch_symbol
                st.rerun()
        
        # Add to watchlist
        new_symbol = st.text_input("Add to Watchlist:", key="new_watchlist")
        if st.button("Add Symbol") and new_symbol:
            if new_symbol.upper() not in st.session_state.watchlist:
                st.session_state.watchlist.append(new_symbol.upper())
                st.rerun()
        
        st.markdown("---")
        
        # Market overview
        st.subheader("🌐 Market Overview")
        market_data = get_market_overview()
        for ticker, data in market_data.items():
            st.metric(
                label=ticker,
                value=f"${data['price']:.2f}",
                delta=f"{data['change']:.2f} ({data['change_pct']:.1f}%)"
            )
    
    # Main content area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader(f"📊 Live Data for {symbol}")
        
        # Get stock data
        data_fetcher = DataFetcher()
        try:
            stock_data = data_fetcher.get_stock_data(symbol)
            options_data = data_fetcher.get_options_data(symbol)
            
            if stock_data is not None and not stock_data.empty:
                # Current price and metrics
                current_price = stock_data['Close'].iloc[-1]
                price_change = stock_data['Close'].iloc[-1] - stock_data['Close'].iloc[-2]
                price_change_pct = (price_change / stock_data['Close'].iloc[-2]) * 100
                
                # Display key metrics
                metric_cols = st.columns(4)
                with metric_cols[0]:
                    st.metric("Current Price", f"${current_price:.2f}", f"{price_change:.2f} ({price_change_pct:.1f}%)")
                with metric_cols[1]:
                    st.metric("Volume", f"{stock_data['Volume'].iloc[-1]:,}")
                with metric_cols[2]:
                    st.metric("Day High", f"${stock_data['High'].iloc[-1]:.2f}")
                with metric_cols[3]:
                    st.metric("Day Low", f"${stock_data['Low'].iloc[-1]:.2f}")
                
                # Price chart
                fig = go.Figure()
                fig.add_trace(go.Candlestick(
                    x=stock_data.index,
                    open=stock_data['Open'],
                    high=stock_data['High'],
                    low=stock_data['Low'],
                    close=stock_data['Close'],
                    name=symbol
                ))
                fig.update_layout(
                    title=f"{symbol} Price Chart",
                    xaxis_title="Date",
                    yaxis_title="Price ($)",
                    height=400
                )
                st.plotly_chart(fig, use_container_width=True)
                
            else:
                st.error(f"Could not fetch data for {symbol}. Please check the symbol and try again.")
                
        except Exception as e:
            st.error(f"Error fetching data: {str(e)}")
    
    with col2:
        st.subheader("🎯 Quick Actions")
        
        # Options chain preview
        try:
            options_data = data_fetcher.get_options_data(symbol)
        except:
            options_data = None
            
        if options_data:
            st.write("**Options Chain Preview**")
            
            # Get nearest expiration
            exp_dates = list(options_data.keys())
            if exp_dates:
                nearest_exp = exp_dates[0]
                calls = options_data[nearest_exp]['calls']
                puts = options_data[nearest_exp]['puts']
                
                st.write(f"Expiration: {nearest_exp}")
                
                # Show ATM options
                if not calls.empty and not puts.empty:
                    atm_calls = calls.iloc[0:3]
                    atm_puts = puts.iloc[0:3]
                    
                    st.write("**Top Calls**")
                    for _, row in atm_calls.iterrows():
                        st.write(f"${row['strike']}: ${row['lastPrice']:.2f}")
                    
                    st.write("**Top Puts**")
                    for _, row in atm_puts.iterrows():
                        st.write(f"${row['strike']}: ${row['lastPrice']:.2f}")
        
        # Portfolio summary
        st.subheader("💼 Portfolio Summary")
        if st.session_state.portfolio:
            total_value = sum([pos['value'] for pos in st.session_state.portfolio])
            st.metric("Total Portfolio Value", f"${total_value:,.2f}")
            
            # Show top positions
            st.write("**Top Positions**")
            for pos in st.session_state.portfolio[:3]:
                st.write(f"{pos['symbol']}: ${pos['value']:,.2f}")
        else:
            st.info("No positions in portfolio. Add positions from the Portfolio Tracker page.")
    
    # Quick analysis section
    st.markdown("---")
    st.subheader("🔍 Quick Analysis")
    
    analysis_cols = st.columns(3)
    
    with analysis_cols[0]:
        st.write("**Options Analysis**")
        if st.button("Analyze Options Chain", type="primary"):
            st.switch_page("pages/1_Options_Analysis.py")
        st.write("View detailed options data, Greeks, and pricing analysis")
    
    with analysis_cols[1]:
        st.write("**Risk Management**")
        if st.button("Risk Dashboard", type="primary"):
            st.switch_page("pages/2_Risk_Management.py")
        st.write("Assess portfolio risk and get position sizing recommendations")
    
    with analysis_cols[2]:
        st.write("**Technical Analysis**")
        if st.button("Technical Indicators", type="primary"):
            st.switch_page("pages/4_Technical_Analysis.py")
        st.write("Analyze technical indicators and trading signals")
    
    # Advanced trading tools
    st.markdown("---")
    st.subheader("⚡ Advanced Trading Tools")
    
    tools_cols = st.columns(4)
    
    with tools_cols[0]:
        st.write("**Backtesting Engine**")
        if st.button("Run Backtests", type="secondary"):
            st.switch_page("pages/5_Backtesting.py")
        st.write("Test strategies with historical data like Tradezella")
    
    with tools_cols[1]:
        st.write("**Performance Tracker**")
        if st.button("Track Performance", type="secondary"):
            st.switch_page("pages/6_Performance_Tracker.py")
        st.write("Journal trades and analyze performance patterns")
    
    with tools_cols[2]:
        st.write("**Portfolio Tracker**")
        if st.button("Track Portfolio", type="secondary"):
            st.switch_page("pages/3_Portfolio_Tracker.py")
        st.write("Monitor positions and real-time P&L")
    
    with tools_cols[3]:
        st.write("**AI Psychology Coach**")
        if st.button("Get Coaching", type="secondary"):
            st.switch_page("pages/7_AI_Psychology_Coach.py")
        st.write("Improve trading psychology with AI guidance")

@st.cache_data(ttl=60)
def get_market_overview():
    """Get overview of major market indices"""
    indices = {
        'SPY': 'S&P 500',
        'QQQ': 'NASDAQ',
        'DIA': 'DOW',
        'IVV': 'S&P Index'  # Using IVV instead of VIX which seems to have issues
    }
    
    market_data = {}
    for ticker, name in indices.items():
        try:
            ticker_obj = yf.Ticker(ticker)
            hist = ticker_obj.history(period='2d')
            if hist is not None and len(hist) >= 2:
                current = float(hist['Close'].iloc[-1])
                previous = float(hist['Close'].iloc[-2])
                change = current - previous
                change_pct = (change / previous) * 100
                
                market_data[name] = {
                    'price': current,
                    'change': change,
                    'change_pct': change_pct
                }
            else:
                market_data[name] = {
                    'price': 0.0,
                    'change': 0.0,
                    'change_pct': 0.0
                }
        except Exception as e:
            market_data[name] = {
                'price': 0.0,
                'change': 0.0,
                'change_pct': 0.0
            }
    
    return market_data

if __name__ == "__main__":
    main()
