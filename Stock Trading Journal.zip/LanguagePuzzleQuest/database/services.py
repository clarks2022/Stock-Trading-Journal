"""
Database service functions for the Stock Options Analysis application
"""
import json
from datetime import datetime
from typing import List, Dict, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc, and_
from database.models import (
    User, PortfolioPosition, Trade, PsychologyAssessment, 
    BacktestResult, Watchlist, ChatHistory, SessionLocal
)

class DatabaseService:
    """Service class for database operations"""
    
    def __init__(self):
        self.db = SessionLocal()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.db.close()
    
    def get_or_create_user(self, username: str = "default_user", email: str = "user@example.com") -> User:
        """Get or create a default user"""
        user = self.db.query(User).filter(User.username == username).first()
        if not user:
            user = User(username=username, email=email)
            self.db.add(user)
            self.db.commit()
            self.db.refresh(user)
        return user
    
    # Portfolio operations
    def add_portfolio_position(self, user_id: int, symbol: str, position_type: str, 
                              quantity: float, entry_price: float, entry_date: datetime) -> PortfolioPosition:
        """Add a new portfolio position"""
        position = PortfolioPosition(
            user_id=user_id,
            symbol=symbol,
            position_type=position_type,
            quantity=quantity,
            entry_price=entry_price,
            current_price=entry_price,  # Will be updated later
            entry_date=entry_date
        )
        self.db.add(position)
        self.db.commit()
        self.db.refresh(position)
        return position
    
    def get_portfolio_positions(self, user_id: int) -> List[PortfolioPosition]:
        """Get all portfolio positions for a user"""
        return self.db.query(PortfolioPosition).filter(PortfolioPosition.user_id == user_id).all()
    
    def update_position_price(self, position_id: int, current_price: float):
        """Update the current price of a position"""
        position = self.db.query(PortfolioPosition).filter(PortfolioPosition.id == position_id).first()
        if position:
            position.current_price = current_price
            position.last_updated = datetime.utcnow()
            self.db.commit()
    
    def delete_portfolio_position(self, position_id: int):
        """Delete a portfolio position"""
        position = self.db.query(PortfolioPosition).filter(PortfolioPosition.id == position_id).first()
        if position:
            self.db.delete(position)
            self.db.commit()
    
    # Trade operations
    def add_trade(self, user_id: int, symbol: str, action: str, quantity: float, 
                  price: float, commission: float, pnl: float, strategy: str = None,
                  setup: str = None, emotion: str = None, confidence: int = None,
                  notes: str = None, tag: str = None, trade_date: datetime = None) -> Trade:
        """Add a new trade"""
        trade = Trade(
            user_id=user_id,
            symbol=symbol,
            action=action,
            quantity=quantity,
            price=price,
            commission=commission,
            pnl=pnl,
            strategy=strategy,
            setup=setup,
            emotion=emotion,
            confidence=confidence,
            notes=notes,
            tag=tag,
            trade_date=trade_date or datetime.utcnow()
        )
        self.db.add(trade)
        self.db.commit()
        self.db.refresh(trade)
        return trade
    
    def get_trades(self, user_id: int, limit: int = 100) -> List[Trade]:
        """Get trades for a user"""
        return (self.db.query(Trade)
                .filter(Trade.user_id == user_id)
                .order_by(desc(Trade.trade_date))
                .limit(limit)
                .all())
    
    def get_trades_by_symbol(self, user_id: int, symbol: str) -> List[Trade]:
        """Get trades for a specific symbol"""
        return (self.db.query(Trade)
                .filter(and_(Trade.user_id == user_id, Trade.symbol == symbol))
                .order_by(desc(Trade.trade_date))
                .all())
    
    def get_trades_by_strategy(self, user_id: int, strategy: str) -> List[Trade]:
        """Get trades for a specific strategy"""
        return (self.db.query(Trade)
                .filter(and_(Trade.user_id == user_id, Trade.strategy == strategy))
                .order_by(desc(Trade.trade_date))
                .all())
    
    # Psychology assessment operations
    def save_psychology_assessment(self, user_id: int, risk_tolerance: str, 
                                 emotional_state: str, trading_experience: str,
                                 current_mood: str, stress_level: int, 
                                 confidence_level: int, psychology_score: float) -> PsychologyAssessment:
        """Save a psychology assessment"""
        assessment = PsychologyAssessment(
            user_id=user_id,
            risk_tolerance=risk_tolerance,
            emotional_state=emotional_state,
            trading_experience=trading_experience,
            current_mood=current_mood,
            stress_level=stress_level,
            confidence_level=confidence_level,
            psychology_score=psychology_score
        )
        self.db.add(assessment)
        self.db.commit()
        self.db.refresh(assessment)
        return assessment
    
    def get_latest_psychology_assessment(self, user_id: int) -> Optional[PsychologyAssessment]:
        """Get the latest psychology assessment for a user"""
        return (self.db.query(PsychologyAssessment)
                .filter(PsychologyAssessment.user_id == user_id)
                .order_by(desc(PsychologyAssessment.assessment_date))
                .first())
    
    def get_psychology_assessments(self, user_id: int, limit: int = 10) -> List[PsychologyAssessment]:
        """Get psychology assessments for a user"""
        return (self.db.query(PsychologyAssessment)
                .filter(PsychologyAssessment.user_id == user_id)
                .order_by(desc(PsychologyAssessment.assessment_date))
                .limit(limit)
                .all())
    
    # Backtest operations
    def save_backtest_result(self, user_id: int, symbol: str, strategy_type: str,
                           start_date: datetime, end_date: datetime, 
                           results: Dict) -> BacktestResult:
        """Save backtest results"""
        backtest = BacktestResult(
            user_id=user_id,
            symbol=symbol,
            strategy_type=strategy_type,
            start_date=start_date,
            end_date=end_date,
            initial_capital=results.get('initial_capital', 0),
            final_capital=results.get('final_capital', 0),
            total_return=results.get('total_return', 0),
            annual_return=results.get('annual_return', 0),
            sharpe_ratio=results.get('sharpe_ratio', 0),
            max_drawdown=results.get('max_drawdown', 0),
            win_rate=results.get('win_rate', 0),
            total_trades=results.get('total_trades', 0),
            winning_trades=results.get('winning_trades', 0),
            losing_trades=results.get('losing_trades', 0),
            avg_win=results.get('avg_win', 0),
            avg_loss=results.get('avg_loss', 0),
            profit_factor=results.get('profit_factor', 0),
            sortino_ratio=results.get('sortino_ratio', 0),
            strategy_params=json.dumps(results.get('strategy_params', {}))
        )
        self.db.add(backtest)
        self.db.commit()
        self.db.refresh(backtest)
        return backtest
    
    def get_backtest_results(self, user_id: int, limit: int = 20) -> List[BacktestResult]:
        """Get backtest results for a user"""
        return (self.db.query(BacktestResult)
                .filter(BacktestResult.user_id == user_id)
                .order_by(desc(BacktestResult.created_at))
                .limit(limit)
                .all())
    
    # Watchlist operations
    def add_to_watchlist(self, user_id: int, symbol: str, name: str = None,
                        sector: str = None, notes: str = None) -> Watchlist:
        """Add symbol to watchlist"""
        watchlist_item = Watchlist(
            user_id=user_id,
            symbol=symbol,
            name=name,
            sector=sector,
            notes=notes
        )
        self.db.add(watchlist_item)
        self.db.commit()
        self.db.refresh(watchlist_item)
        return watchlist_item
    
    def get_watchlist(self, user_id: int) -> List[Watchlist]:
        """Get watchlist for a user"""
        return (self.db.query(Watchlist)
                .filter(Watchlist.user_id == user_id)
                .order_by(desc(Watchlist.added_date))
                .all())
    
    def remove_from_watchlist(self, user_id: int, symbol: str):
        """Remove symbol from watchlist"""
        item = (self.db.query(Watchlist)
                .filter(and_(Watchlist.user_id == user_id, Watchlist.symbol == symbol))
                .first())
        if item:
            self.db.delete(item)
            self.db.commit()
    
    # Chat history operations
    def save_chat_message(self, user_id: int, message: str, response: str, 
                         message_type: str = 'general') -> ChatHistory:
        """Save chat message and response"""
        chat = ChatHistory(
            user_id=user_id,
            message=message,
            response=response,
            message_type=message_type
        )
        self.db.add(chat)
        self.db.commit()
        self.db.refresh(chat)
        return chat
    
    def get_chat_history(self, user_id: int, limit: int = 50) -> List[ChatHistory]:
        """Get chat history for a user"""
        return (self.db.query(ChatHistory)
                .filter(ChatHistory.user_id == user_id)
                .order_by(desc(ChatHistory.created_at))
                .limit(limit)
                .all())
    
    def get_chat_history_by_type(self, user_id: int, message_type: str, 
                                limit: int = 20) -> List[ChatHistory]:
        """Get chat history by message type"""
        return (self.db.query(ChatHistory)
                .filter(and_(ChatHistory.user_id == user_id, 
                           ChatHistory.message_type == message_type))
                .order_by(desc(ChatHistory.created_at))
                .limit(limit)
                .all())

# Utility functions
def get_database_service() -> DatabaseService:
    """Get database service instance"""
    return DatabaseService()