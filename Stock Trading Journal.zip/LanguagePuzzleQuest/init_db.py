#!/usr/bin/env python3
"""
Script to initialize the database tables
"""
import os
import sys
from database.models import init_db

def main():
    try:
        print("Initializing database...")
        init_db()
        print("Database initialized successfully!")
        
        # Test connection
        from database.services import get_database_service
        with get_database_service() as db_service:
            user = db_service.get_or_create_user()
            print(f"Created/found user: {user.username} (ID: {user.id})")
        
        print("Database test completed successfully!")
        
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()