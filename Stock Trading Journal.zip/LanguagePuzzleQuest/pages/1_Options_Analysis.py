import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
from utils.data_fetcher import DataFetcher
from utils.options_pricing import OptionsCalculator

st.set_page_config(
    page_title="Options Analysis",
    page_icon="🎯",
    layout="wide"
)

def main():
    st.title("🎯 Options Analysis")
    st.markdown("---")
    
    # Sidebar controls
    with st.sidebar:
        st.header("🎯 Options Parameters")
        
        # Symbol input
        symbol = st.text_input("Stock Symbol:", value="AAPL", key="options_symbol").upper()
        
        # Options type
        option_type = st.selectbox("Option Type:", ["Call", "Put"])
        
        # Strike price input
        strike_price = st.number_input("Strike Price ($):", min_value=0.0, value=150.0, step=5.0)
        
        # Risk-free rate
        risk_free_rate = st.number_input("Risk-free Rate (%):", min_value=0.0, max_value=10.0, value=5.0, step=0.1) / 100
        
        st.markdown("---")
        
        # Analysis options
        st.subheader("📊 Analysis Options")
        show_greeks = st.checkbox("Show Greeks", value=True)
        show_payoff = st.checkbox("Show Payoff Diagram", value=True)
        show_volatility = st.checkbox("Show Volatility Analysis", value=True)
    
    # Main content
    data_fetcher = DataFetcher()
    options_calc = OptionsCalculator()
    
    try:
        # Get stock data
        stock_data = data_fetcher.get_stock_data(symbol)
        options_data = data_fetcher.get_options_data(symbol)
        
        if stock_data is not None and not stock_data.empty:
            current_price = stock_data['Close'].iloc[-1]
            
            # Display current stock info
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Current Price", f"${current_price:.2f}")
            with col2:
                volatility = stock_data['Close'].pct_change().std() * np.sqrt(252)
                st.metric("Implied Volatility", f"{volatility:.1%}")
            with col3:
                volume = stock_data['Volume'].iloc[-1]
                st.metric("Volume", f"{volume:,}")
            with col4:
                price_change = stock_data['Close'].iloc[-1] - stock_data['Close'].iloc[-2]
                price_change_pct = (price_change / stock_data['Close'].iloc[-2]) * 100
                st.metric("Daily Change", f"{price_change:.2f}", f"{price_change_pct:.1f}%")
            
            st.markdown("---")
            
            # Options chain analysis
            if options_data:
                st.subheader("📋 Options Chain Analysis")
                
                # Expiration date selection
                exp_dates = list(options_data.keys())
                selected_exp = st.selectbox("Select Expiration Date:", exp_dates)
                
                if selected_exp:
                    # Get options data for selected expiration
                    calls = options_data[selected_exp]['calls']
                    puts = options_data[selected_exp]['puts']
                    
                    # Display options chain
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.subheader("📈 Call Options")
                        if not calls.empty:
                            # Format calls data
                            calls_display = calls[['strike', 'lastPrice', 'volume', 'impliedVolatility']].copy()
                            calls_display['impliedVolatility'] = calls_display['impliedVolatility'] * 100
                            calls_display = calls_display.round(2)
                            calls_display.columns = ['Strike', 'Last Price', 'Volume', 'IV (%)']
                            st.dataframe(calls_display, use_container_width=True)
                    
                    with col2:
                        st.subheader("📉 Put Options")
                        if not puts.empty:
                            # Format puts data
                            puts_display = puts[['strike', 'lastPrice', 'volume', 'impliedVolatility']].copy()
                            puts_display['impliedVolatility'] = puts_display['impliedVolatility'] * 100
                            puts_display = puts_display.round(2)
                            puts_display.columns = ['Strike', 'Last Price', 'Volume', 'IV (%)']
                            st.dataframe(puts_display, use_container_width=True)
                    
                    # Calculate days to expiration
                    exp_date = datetime.strptime(selected_exp, '%Y-%m-%d')
                    days_to_exp = (exp_date - datetime.now()).days
                    time_to_exp = days_to_exp / 365.0
                    
                    st.markdown("---")
                    
                    # Black-Scholes Analysis
                    st.subheader("🧮 Black-Scholes Analysis")
                    
                    if time_to_exp > 0:
                        # Calculate theoretical price
                        theoretical_price = options_calc.black_scholes(
                            current_price, strike_price, time_to_exp, 
                            risk_free_rate, volatility, option_type.lower()
                        )
                        
                        # Calculate Greeks
                        greeks = options_calc.calculate_greeks(
                            current_price, strike_price, time_to_exp,
                            risk_free_rate, volatility, option_type.lower()
                        )
                        
                        # Display results
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.metric("Theoretical Price", f"${theoretical_price:.2f}")
                            st.metric("Strike Price", f"${strike_price:.2f}")
                            st.metric("Days to Expiration", f"{days_to_exp}")
                        
                        with col2:
                            if show_greeks:
                                st.metric("Delta", f"{greeks['delta']:.4f}")
                                st.metric("Gamma", f"{greeks['gamma']:.4f}")
                                st.metric("Theta", f"{greeks['theta']:.4f}")
                        
                        with col3:
                            if show_greeks:
                                st.metric("Vega", f"{greeks['vega']:.4f}")
                                st.metric("Rho", f"{greeks['rho']:.4f}")
                                st.metric("Implied Vol", f"{volatility:.1%}")
                        
                        # Payoff diagram
                        if show_payoff:
                            st.markdown("---")
                            st.subheader("📊 Payoff Diagram")
                            
                            # Generate payoff diagram
                            spot_range = np.linspace(current_price * 0.7, current_price * 1.3, 100)
                            payoffs = []
                            
                            for spot in spot_range:
                                if option_type.lower() == 'call':
                                    payoff = max(spot - strike_price, 0) - theoretical_price
                                else:
                                    payoff = max(strike_price - spot, 0) - theoretical_price
                                payoffs.append(payoff)
                            
                            # Create plotly figure
                            fig = go.Figure()
                            fig.add_trace(go.Scatter(
                                x=spot_range,
                                y=payoffs,
                                mode='lines',
                                name=f'{option_type} Option P&L',
                                line=dict(color='blue', width=2)
                            ))
                            
                            # Add breakeven line
                            fig.add_hline(y=0, line_dash="dash", line_color="red", 
                                         annotation_text="Breakeven")
                            
                            # Add current price line
                            fig.add_vline(x=current_price, line_dash="dash", line_color="green",
                                         annotation_text=f"Current Price: ${current_price:.2f}")
                            
                            fig.update_layout(
                                title=f'{symbol} {option_type} Option Payoff Diagram',
                                xaxis_title='Stock Price at Expiration ($)',
                                yaxis_title='Profit/Loss ($)',
                                height=400
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                        
                        # Volatility analysis
                        if show_volatility:
                            st.markdown("---")
                            st.subheader("📈 Volatility Analysis")
                            
                            # Calculate option prices for different volatilities
                            vol_range = np.linspace(0.1, 1.0, 20)
                            vol_prices = []
                            
                            for vol in vol_range:
                                price = options_calc.black_scholes(
                                    current_price, strike_price, time_to_exp,
                                    risk_free_rate, vol, option_type.lower()
                                )
                                vol_prices.append(price)
                            
                            # Create volatility chart
                            fig = go.Figure()
                            fig.add_trace(go.Scatter(
                                x=vol_range * 100,
                                y=vol_prices,
                                mode='lines+markers',
                                name='Option Price',
                                line=dict(color='purple', width=2)
                            ))
                            
                            # Add current volatility line
                            fig.add_vline(x=volatility * 100, line_dash="dash", line_color="orange",
                                         annotation_text=f"Current IV: {volatility:.1%}")
                            
                            fig.update_layout(
                                title='Option Price vs Implied Volatility',
                                xaxis_title='Implied Volatility (%)',
                                yaxis_title='Option Price ($)',
                                height=400
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                    
                    else:
                        st.error("Option has expired or expiration date is invalid.")
            
            else:
                st.warning("No options data available for this symbol.")
        
        else:
            st.error(f"Could not fetch data for {symbol}. Please check the symbol and try again.")
    
    except Exception as e:
        st.error(f"Error in options analysis: {str(e)}")
        st.error("Please check your inputs and try again.")

if __name__ == "__main__":
    main()
