import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from utils.risk_management import RiskManager
from utils.data_fetcher import DataFetcher
import yfinance as yf

st.set_page_config(
    page_title="Risk Management",
    page_icon="🛡️",
    layout="wide"
)

def main():
    st.title("🛡️ Risk Management Dashboard")
    st.markdown("---")
    
    # Initialize risk manager
    risk_manager = RiskManager()
    
    # Sidebar controls
    with st.sidebar:
        st.header("🎯 Risk Parameters")
        
        # Portfolio settings
        portfolio_value = st.number_input("Portfolio Value ($):", min_value=1000.0, value=100000.0, step=1000.0)
        risk_tolerance = st.slider("Risk Tolerance (%):", min_value=1.0, max_value=10.0, value=2.0, step=0.5)
        
        # Position sizing method
        position_method = st.selectbox("Position Sizing Method:", 
                                     ["Fixed Percentage", "Kelly Criterion", "Volatility Based"])
        
        # Risk metrics
        st.subheader("🎯 Risk Metrics")
        max_position_size = st.slider("Max Position Size (%):", min_value=1.0, max_value=25.0, value=10.0, step=1.0)
        stop_loss_pct = st.slider("Stop Loss (%):", min_value=1.0, max_value=20.0, value=5.0, step=0.5)
        
        st.markdown("---")
        
        # Alert settings
        st.subheader("🚨 Alert Settings")
        portfolio_risk_alert = st.slider("Portfolio Risk Alert (%):", min_value=1.0, max_value=15.0, value=5.0, step=0.5)
        correlation_alert = st.slider("Correlation Alert:", min_value=0.5, max_value=1.0, value=0.8, step=0.05)
    
    # Main content
    tab1, tab2, tab3, tab4 = st.tabs(["📊 Portfolio Risk", "📈 Position Sizing", "🎯 Risk Metrics", "🚨 Alerts"])
    
    with tab1:
        st.subheader("📊 Portfolio Risk Analysis")
        
        # Portfolio composition input
        st.write("**Enter Portfolio Positions:**")
        
        # Initialize portfolio in session state
        if 'risk_portfolio' not in st.session_state:
            st.session_state.risk_portfolio = pd.DataFrame(columns=['Symbol', 'Shares', 'Price', 'Weight'])
        
        # Add position form
        with st.form("add_position"):
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                symbol = st.text_input("Symbol:", value="AAPL")
            with col2:
                shares = st.number_input("Shares:", min_value=1, value=100)
            with col3:
                price = st.number_input("Price ($):", min_value=0.01, value=150.0)
            with col4:
                st.write("")
                st.write("")
                add_position = st.form_submit_button("Add Position")
        
        if add_position and symbol:
            # Get current price
            try:
                ticker = yf.Ticker(symbol.upper())
                current_price = ticker.history(period='1d')['Close'].iloc[-1]
                value = shares * current_price
                weight = value / portfolio_value * 100
                
                # Add to portfolio
                new_row = pd.DataFrame({
                    'Symbol': [symbol.upper()],
                    'Shares': [shares],
                    'Price': [current_price],
                    'Value': [value],
                    'Weight': [weight]
                })
                st.session_state.risk_portfolio = pd.concat([st.session_state.risk_portfolio, new_row], ignore_index=True)
                st.rerun()
            except:
                st.error(f"Could not fetch price for {symbol}")
        
        # Display portfolio
        if not st.session_state.risk_portfolio.empty:
            st.dataframe(st.session_state.risk_portfolio.round(2), use_container_width=True)
            
            # Portfolio risk metrics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                total_value = st.session_state.risk_portfolio['Value'].sum()
                st.metric("Total Portfolio Value", f"${total_value:,.2f}")
            
            with col2:
                # Calculate portfolio concentration
                max_weight = st.session_state.risk_portfolio['Weight'].max()
                st.metric("Largest Position", f"{max_weight:.1f}%")
            
            with col3:
                # Number of positions
                num_positions = len(st.session_state.risk_portfolio)
                st.metric("Number of Positions", num_positions)
            
            # Portfolio composition pie chart
            fig = px.pie(
                st.session_state.risk_portfolio,
                values='Value',
                names='Symbol',
                title='Portfolio Composition'
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # Risk analysis
            st.subheader("🎯 Risk Analysis")
            
            # Calculate portfolio risk metrics
            symbols = st.session_state.risk_portfolio['Symbol'].tolist()
            weights = st.session_state.risk_portfolio['Weight'].values / 100
            
            # Get historical data for risk calculation
            try:
                data_fetcher = DataFetcher()
                risk_data = {}
                
                for symbol in symbols:
                    stock_data = data_fetcher.get_stock_data(symbol, period='1y')
                    if stock_data is not None:
                        risk_data[symbol] = stock_data['Close'].pct_change().dropna()
                
                if risk_data:
                    # Create returns dataframe
                    returns_df = pd.DataFrame(risk_data)
                    
                    # Calculate correlation matrix
                    correlation_matrix = returns_df.corr()
                    
                    # Display correlation heatmap
                    fig = px.imshow(
                        correlation_matrix,
                        title='Portfolio Correlation Matrix',
                        color_continuous_scale='RdBu',
                        aspect='auto'
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Portfolio risk metrics
                    portfolio_returns = (returns_df * weights).sum(axis=1)
                    portfolio_volatility = portfolio_returns.std() * np.sqrt(252)
                    portfolio_var = np.percentile(portfolio_returns, 5)
                    
                    risk_col1, risk_col2, risk_col3 = st.columns(3)
                    
                    with risk_col1:
                        st.metric("Portfolio Volatility", f"{portfolio_volatility:.1%}")
                    with risk_col2:
                        st.metric("Daily VaR (95%)", f"{portfolio_var:.2%}")
                    with risk_col3:
                        diversification_ratio = len(symbols) / max_weight * 10
                        st.metric("Diversification Score", f"{min(diversification_ratio, 10):.1f}/10")
                    
            except Exception as e:
                st.error(f"Error calculating portfolio risk: {str(e)}")
        
        else:
            st.info("Add positions to analyze portfolio risk.")
    
    with tab2:
        st.subheader("📈 Position Sizing Calculator")
        
        # Position sizing inputs
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Trade Parameters:**")
            entry_price = st.number_input("Entry Price ($):", min_value=0.01, value=150.0)
            stop_loss_price = st.number_input("Stop Loss Price ($):", min_value=0.01, value=142.5)
            target_price = st.number_input("Target Price ($):", min_value=0.01, value=165.0)
        
        with col2:
            st.write("**Account Parameters:**")
            account_size = st.number_input("Account Size ($):", min_value=1000.0, value=portfolio_value)
            risk_per_trade = st.slider("Risk per Trade (%):", min_value=0.5, max_value=5.0, value=1.0, step=0.1)
        
        # Calculate position size
        risk_amount = account_size * (risk_per_trade / 100)
        risk_per_share = abs(entry_price - stop_loss_price)
        
        if risk_per_share > 0:
            position_size = int(risk_amount / risk_per_share)
            position_value = position_size * entry_price
            
            # Display results
            st.markdown("---")
            st.subheader("📊 Position Sizing Results")
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Position Size", f"{position_size} shares")
            with col2:
                st.metric("Position Value", f"${position_value:,.2f}")
            with col3:
                st.metric("Risk Amount", f"${risk_amount:.2f}")
            with col4:
                risk_reward = abs(target_price - entry_price) / risk_per_share
                st.metric("Risk:Reward Ratio", f"1:{risk_reward:.2f}")
            
            # Position sizing visualization
            fig = go.Figure()
            
            # Add price levels
            fig.add_hline(y=entry_price, line_dash="solid", line_color="blue", 
                         annotation_text=f"Entry: ${entry_price:.2f}")
            fig.add_hline(y=stop_loss_price, line_dash="dash", line_color="red",
                         annotation_text=f"Stop Loss: ${stop_loss_price:.2f}")
            fig.add_hline(y=target_price, line_dash="dash", line_color="green",
                         annotation_text=f"Target: ${target_price:.2f}")
            
            # Add risk/reward zones
            fig.add_hrect(y0=stop_loss_price, y1=entry_price, 
                         fillcolor="red", opacity=0.2, annotation_text="Risk Zone")
            fig.add_hrect(y0=entry_price, y1=target_price, 
                         fillcolor="green", opacity=0.2, annotation_text="Reward Zone")
            
            fig.update_layout(
                title="Risk/Reward Visualization",
                yaxis_title="Price ($)",
                height=400,
                showlegend=False
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Risk assessment
            st.subheader("🎯 Risk Assessment")
            
            max_loss = position_size * risk_per_share
            max_gain = position_size * abs(target_price - entry_price)
            
            assessment_col1, assessment_col2 = st.columns(2)
            
            with assessment_col1:
                st.metric("Maximum Loss", f"${max_loss:.2f}")
                portfolio_risk_pct = (max_loss / account_size) * 100
                st.metric("Portfolio Risk", f"{portfolio_risk_pct:.2f}%")
            
            with assessment_col2:
                st.metric("Maximum Gain", f"${max_gain:.2f}")
                st.metric("Position % of Portfolio", f"{(position_value/account_size)*100:.1f}%")
            
            # Risk warnings
            if portfolio_risk_pct > risk_tolerance:
                st.warning(f"⚠️ Position risk ({portfolio_risk_pct:.1f}%) exceeds risk tolerance ({risk_tolerance:.1f}%)")
            
            if (position_value/account_size)*100 > max_position_size:
                st.warning(f"⚠️ Position size ({(position_value/account_size)*100:.1f}%) exceeds maximum position size ({max_position_size:.1f}%)")
            
            if risk_reward < 1.5:
                st.warning(f"⚠️ Risk:Reward ratio ({risk_reward:.2f}) is below recommended minimum of 1.5")
    
    with tab3:
        st.subheader("🎯 Risk Metrics Dashboard")
        
        # Key risk metrics
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.write("**Portfolio Metrics**")
            st.metric("Total Portfolio Value", f"${portfolio_value:,.2f}")
            st.metric("Risk Tolerance", f"{risk_tolerance:.1f}%")
            st.metric("Max Position Size", f"{max_position_size:.1f}%")
        
        with col2:
            st.write("**Risk Limits**")
            daily_risk_limit = portfolio_value * (risk_tolerance / 100)
            st.metric("Daily Risk Limit", f"${daily_risk_limit:,.2f}")
            st.metric("Stop Loss %", f"{stop_loss_pct:.1f}%")
            weekly_risk_limit = daily_risk_limit * 3
            st.metric("Weekly Risk Limit", f"${weekly_risk_limit:,.2f}")
        
        with col3:
            st.write("**Alert Thresholds**")
            st.metric("Portfolio Risk Alert", f"{portfolio_risk_alert:.1f}%")
            st.metric("Correlation Alert", f"{correlation_alert:.2f}")
            volatility_alert = 0.3
            st.metric("Volatility Alert", f"{volatility_alert:.1%}")
        
        # Risk monitoring chart
        st.subheader("📊 Risk Monitoring")
        
        # Simulate daily P&L for demonstration
        dates = pd.date_range(start='2024-01-01', periods=30, freq='D')
        daily_returns = np.random.normal(0.001, 0.02, 30)
        cumulative_returns = np.cumsum(daily_returns)
        portfolio_values = portfolio_value * (1 + cumulative_returns)
        
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=dates,
            y=portfolio_values,
            mode='lines',
            name='Portfolio Value',
            line=dict(color='blue', width=2)
        ))
        
        # Add risk limits
        fig.add_hline(y=portfolio_value * (1 - risk_tolerance/100), 
                     line_dash="dash", line_color="red",
                     annotation_text="Risk Limit")
        fig.add_hline(y=portfolio_value, 
                     line_dash="dash", line_color="green",
                     annotation_text="Initial Value")
        
        fig.update_layout(
            title="Portfolio Value vs Risk Limits",
            xaxis_title="Date",
            yaxis_title="Portfolio Value ($)",
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    with tab4:
        st.subheader("🚨 Risk Alerts & Monitoring")
        
        # Alert status
        st.write("**Current Alert Status:**")
        
        # Sample alerts (in real implementation, these would be calculated based on actual data)
        alerts = [
            {"type": "Portfolio Risk", "status": "Normal", "value": "1.2%", "threshold": f"{portfolio_risk_alert}%"},
            {"type": "Position Concentration", "status": "Warning", "value": "12%", "threshold": f"{max_position_size}%"},
            {"type": "Correlation Risk", "status": "Normal", "value": "0.65", "threshold": f"{correlation_alert}"},
            {"type": "Volatility Spike", "status": "Alert", "value": "35%", "threshold": "30%"},
        ]
        
        for alert in alerts:
            col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
            
            with col1:
                st.write(alert["type"])
            with col2:
                if alert["status"] == "Normal":
                    st.success(alert["status"])
                elif alert["status"] == "Warning":
                    st.warning(alert["status"])
                else:
                    st.error(alert["status"])
            with col3:
                st.write(alert["value"])
            with col4:
                st.write(alert["threshold"])
        
        st.markdown("---")
        
        # Risk recommendations
        st.subheader("💡 Risk Management Recommendations")
        
        recommendations = [
            "✅ Current portfolio risk is within acceptable limits",
            "⚠️ Consider reducing position size in highly correlated assets",
            "🔄 Rebalance portfolio to maintain target allocations",
            "📊 Monitor volatility levels - consider protective strategies",
            "🎯 Review stop-loss levels for all positions"
        ]
        
        for rec in recommendations:
            st.write(rec)
        
        # Risk management actions
        st.subheader("🎯 Quick Actions")
        
        action_col1, action_col2, action_col3 = st.columns(3)
        
        with action_col1:
            if st.button("🔄 Rebalance Portfolio", type="primary"):
                st.info("Portfolio rebalancing recommendations will be generated based on current positions.")
        
        with action_col2:
            if st.button("📊 Update Risk Limits", type="primary"):
                st.info("Risk limits updated successfully.")
        
        with action_col3:
            if st.button("🚨 Generate Risk Report", type="primary"):
                st.info("Comprehensive risk report will be generated and can be downloaded.")

if __name__ == "__main__":
    main()
