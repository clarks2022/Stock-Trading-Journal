import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import yfinance as yf
from datetime import datetime, timedelta
from utils.data_fetcher import DataFetcher
from database import get_database_service

st.set_page_config(
    page_title="Portfolio Tracker",
    page_icon="💼",
    layout="wide"
)

def main():
    st.title("💼 Portfolio Tracker")
    st.markdown("---")
    
    # Initialize portfolio in session state
    if 'portfolio_positions' not in st.session_state:
        st.session_state.portfolio_positions = pd.DataFrame(columns=[
            'Symbol', 'Type', 'Quantity', 'Entry_Price', 'Current_Price', 
            'Entry_Date', 'P&L', 'P&L_Pct', 'Value'
        ])
    
    # Sidebar controls
    with st.sidebar:
        st.header("💼 Portfolio Management")
        
        # Add position form
        st.subheader("➕ Add New Position")
        
        with st.form("add_portfolio_position"):
            symbol = st.text_input("Symbol:", value="AAPL")
            position_type = st.selectbox("Type:", ["Stock", "Call Option", "Put Option"])
            quantity = st.number_input("Quantity:", min_value=1, value=100)
            entry_price = st.number_input("Entry Price ($):", min_value=0.01, value=150.0)
            entry_date = st.date_input("Entry Date:", value=datetime.now().date())
            
            add_position = st.form_submit_button("Add Position")
        
        if add_position and symbol:
            add_position_to_portfolio(symbol.upper(), position_type, quantity, entry_price, entry_date)
            st.success(f"Added {quantity} shares of {symbol.upper()}")
            st.rerun()
        
        st.markdown("---")
        
        # Portfolio actions
        st.subheader("🎯 Portfolio Actions")
        
        if st.button("🔄 Refresh Prices"):
            update_portfolio_prices()
            st.success("Prices updated!")
            st.rerun()
        
        if st.button("📊 Export Portfolio"):
            st.info("Portfolio export functionality would be implemented here.")
        
        if not st.session_state.portfolio_positions.empty:
            if st.button("🗑️ Clear Portfolio"):
                st.session_state.portfolio_positions = pd.DataFrame(columns=[
                    'Symbol', 'Type', 'Quantity', 'Entry_Price', 'Current_Price', 
                    'Entry_Date', 'P&L', 'P&L_Pct', 'Value'
                ])
                st.success("Portfolio cleared!")
                st.rerun()
    
    # Main content
    if not st.session_state.portfolio_positions.empty:
        # Update current prices
        update_portfolio_prices()
        
        # Portfolio overview
        st.subheader("📊 Portfolio Overview")
        
        # Calculate portfolio metrics
        total_value = st.session_state.portfolio_positions['Value'].sum()
        total_cost = (st.session_state.portfolio_positions['Quantity'] * 
                     st.session_state.portfolio_positions['Entry_Price']).sum()
        total_pnl = total_value - total_cost
        total_pnl_pct = (total_pnl / total_cost) * 100 if total_cost > 0 else 0
        
        # Display key metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Portfolio Value", f"${total_value:,.2f}")
        with col2:
            st.metric("Total Cost Basis", f"${total_cost:,.2f}")
        with col3:
            st.metric("Total P&L", f"${total_pnl:,.2f}", f"{total_pnl_pct:.1f}%")
        with col4:
            num_positions = len(st.session_state.portfolio_positions)
            st.metric("Number of Positions", num_positions)
        
        # Portfolio allocation chart
        col1, col2 = st.columns(2)
        
        with col1:
            # Pie chart of portfolio allocation
            fig = px.pie(
                st.session_state.portfolio_positions,
                values='Value',
                names='Symbol',
                title='Portfolio Allocation by Value'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Bar chart of P&L by position
            fig = px.bar(
                st.session_state.portfolio_positions,
                x='Symbol',
                y='P&L',
                color='P&L',
                color_continuous_scale='RdYlGn',
                title='P&L by Position'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Detailed positions table
        st.subheader("📋 Detailed Positions")
        
        # Format the dataframe for display
        display_df = st.session_state.portfolio_positions.copy()
        display_df['Entry_Price'] = display_df['Entry_Price'].apply(lambda x: f"${x:.2f}")
        display_df['Current_Price'] = display_df['Current_Price'].apply(lambda x: f"${x:.2f}")
        display_df['P&L'] = display_df['P&L'].apply(lambda x: f"${x:.2f}")
        display_df['P&L_Pct'] = display_df['P&L_Pct'].apply(lambda x: f"{x:.1f}%")
        display_df['Value'] = display_df['Value'].apply(lambda x: f"${x:,.2f}")
        
        # Style the dataframe
        st.dataframe(
            display_df,
            use_container_width=True,
            hide_index=True
        )
        
        # Position details
        st.subheader("🔍 Position Analysis")
        
        # Select position for detailed analysis
        selected_symbol = st.selectbox(
            "Select position for detailed analysis:",
            st.session_state.portfolio_positions['Symbol'].unique()
        )
        
        if selected_symbol:
            position_data = st.session_state.portfolio_positions[
                st.session_state.portfolio_positions['Symbol'] == selected_symbol
            ].iloc[0]
            
            # Get historical data for the selected position
            data_fetcher = DataFetcher()
            historical_data = data_fetcher.get_stock_data(selected_symbol, period='3mo')
            
            if historical_data is not None and not historical_data.empty:
                # Position performance chart
                fig = go.Figure()
                
                # Add price chart
                fig.add_trace(go.Scatter(
                    x=historical_data.index,
                    y=historical_data['Close'],
                    mode='lines',
                    name=f'{selected_symbol} Price',
                    line=dict(color='blue', width=2)
                ))
                
                # Add entry price line
                fig.add_hline(
                    y=position_data['Entry_Price'],
                    line_dash="dash",
                    line_color="green",
                    annotation_text=f"Entry Price: ${position_data['Entry_Price']:.2f}"
                )
                
                # Add current price line
                fig.add_hline(
                    y=position_data['Current_Price'],
                    line_dash="dash",
                    line_color="red",
                    annotation_text=f"Current Price: ${position_data['Current_Price']:.2f}"
                )
                
                fig.update_layout(
                    title=f'{selected_symbol} Performance Since Entry',
                    xaxis_title='Date',
                    yaxis_title='Price ($)',
                    height=400
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Position metrics
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Position Value", f"${position_data['Value']:,.2f}")
                    st.metric("Quantity", f"{position_data['Quantity']:,}")
                
                with col2:
                    st.metric("Entry Price", f"${position_data['Entry_Price']:.2f}")
                    st.metric("Current Price", f"${position_data['Current_Price']:.2f}")
                
                with col3:
                    st.metric("P&L", f"${position_data['P&L']:,.2f}", f"{position_data['P&L_Pct']:.1f}%")
                    days_held = (datetime.now().date() - pd.to_datetime(position_data['Entry_Date']).date()).days
                    st.metric("Days Held", days_held)
                
                # Risk metrics for position
                st.subheader("⚠️ Position Risk Analysis")
                
                # Calculate position risk metrics
                returns = historical_data['Close'].pct_change().dropna()
                volatility = returns.std() * np.sqrt(252)
                var_95 = np.percentile(returns, 5)
                max_drawdown = calculate_max_drawdown(historical_data['Close'])
                
                risk_col1, risk_col2, risk_col3 = st.columns(3)
                
                with risk_col1:
                    st.metric("Volatility (Annual)", f"{volatility:.1%}")
                with risk_col2:
                    st.metric("VaR (95%, Daily)", f"{var_95:.2%}")
                with risk_col3:
                    st.metric("Max Drawdown", f"{max_drawdown:.1%}")
                
                # Position recommendations
                st.subheader("💡 Position Recommendations")
                
                recommendations = generate_position_recommendations(
                    position_data, volatility, var_95, max_drawdown
                )
                
                for rec in recommendations:
                    st.write(f"• {rec}")
    
    else:
        st.info("No positions in portfolio. Add your first position using the sidebar.")
        
        # Sample portfolio for demonstration
        st.subheader("📝 Sample Portfolio")
        
        sample_positions = [
            {"Symbol": "AAPL", "Type": "Stock", "Quantity": 100, "Entry_Price": 150.0},
            {"Symbol": "GOOGL", "Type": "Stock", "Quantity": 50, "Entry_Price": 120.0},
            {"Symbol": "MSFT", "Type": "Stock", "Quantity": 75, "Entry_Price": 300.0},
            {"Symbol": "TSLA", "Type": "Stock", "Quantity": 25, "Entry_Price": 200.0},
        ]
        
        st.write("Click below to load a sample portfolio:")
        
        if st.button("Load Sample Portfolio", type="primary"):
            for pos in sample_positions:
                add_position_to_portfolio(
                    pos["Symbol"], pos["Type"], pos["Quantity"], 
                    pos["Entry_Price"], datetime.now().date()
                )
            st.success("Sample portfolio loaded!")
            st.rerun()

def add_position_to_portfolio(symbol, position_type, quantity, entry_price, entry_date):
    """Add a new position to the portfolio"""
    try:
        # Get current price
        ticker = yf.Ticker(symbol)
        current_price = ticker.history(period='1d')['Close'].iloc[-1]
        
        # Calculate P&L
        if position_type == "Stock":
            pnl = (current_price - entry_price) * quantity
        elif position_type == "Call Option":
            pnl = (current_price - entry_price) * quantity * 100  # Options are typically 100 shares
        elif position_type == "Put Option":
            pnl = (entry_price - current_price) * quantity * 100
        
        pnl_pct = (pnl / (entry_price * quantity)) * 100 if entry_price * quantity > 0 else 0
        value = current_price * quantity
        
        # Save to database if user_id exists
        if hasattr(st.session_state, 'user_id') and st.session_state.user_id:
            try:
                with get_database_service() as db_service:
                    db_position = db_service.add_portfolio_position(
                        user_id=st.session_state.user_id,
                        symbol=symbol,
                        position_type=position_type,
                        quantity=quantity,
                        entry_price=entry_price,
                        entry_date=entry_date
                    )
                    st.success(f"Position {symbol} saved to database!")
            except Exception as db_e:
                st.warning(f"Database save failed: {str(db_e)}")
        
        # Create new position
        new_position = pd.DataFrame({
            'Symbol': [symbol],
            'Type': [position_type],
            'Quantity': [quantity],
            'Entry_Price': [entry_price],
            'Current_Price': [current_price],
            'Entry_Date': [entry_date],
            'P&L': [pnl],
            'P&L_Pct': [pnl_pct],
            'Value': [value]
        })
        
        # Add to portfolio
        st.session_state.portfolio_positions = pd.concat([
            st.session_state.portfolio_positions, new_position
        ], ignore_index=True)
        
    except Exception as e:
        st.error(f"Error adding position: {str(e)}")

def update_portfolio_prices():
    """Update current prices for all positions in portfolio"""
    if st.session_state.portfolio_positions.empty:
        return
    
    for idx, position in st.session_state.portfolio_positions.iterrows():
        try:
            ticker = yf.Ticker(position['Symbol'])
            current_price = ticker.history(period='1d')['Close'].iloc[-1]
            
            # Update current price
            st.session_state.portfolio_positions.at[idx, 'Current_Price'] = current_price
            
            # Recalculate P&L
            if position['Type'] == "Stock":
                pnl = (current_price - position['Entry_Price']) * position['Quantity']
            elif position['Type'] == "Call Option":
                pnl = (current_price - position['Entry_Price']) * position['Quantity'] * 100
            elif position['Type'] == "Put Option":
                pnl = (position['Entry_Price'] - current_price) * position['Quantity'] * 100
            
            pnl_pct = (pnl / (position['Entry_Price'] * position['Quantity'])) * 100
            value = current_price * position['Quantity']
            
            st.session_state.portfolio_positions.at[idx, 'P&L'] = pnl
            st.session_state.portfolio_positions.at[idx, 'P&L_Pct'] = pnl_pct
            st.session_state.portfolio_positions.at[idx, 'Value'] = value
            
        except Exception as e:
            st.error(f"Error updating price for {position['Symbol']}: {str(e)}")

def calculate_max_drawdown(prices):
    """Calculate maximum drawdown for a price series"""
    peak = prices.expanding().max()
    drawdown = (prices - peak) / peak
    return drawdown.min()

def generate_position_recommendations(position_data, volatility, var_95, max_drawdown):
    """Generate recommendations based on position analysis"""
    recommendations = []
    
    # Volatility recommendations
    if volatility > 0.3:
        recommendations.append("⚠️ High volatility detected - consider reducing position size")
    elif volatility < 0.15:
        recommendations.append("✅ Low volatility - stable position")
    
    # P&L recommendations
    if position_data['P&L_Pct'] > 20:
        recommendations.append("📈 Strong gains - consider taking some profits")
    elif position_data['P&L_Pct'] < -10:
        recommendations.append("📉 Significant loss - review stop-loss strategy")
    
    # Max drawdown recommendations
    if max_drawdown < -0.2:
        recommendations.append("⚠️ High drawdown risk - monitor closely")
    
    # Time-based recommendations
    days_held = (datetime.now().date() - pd.to_datetime(position_data['Entry_Date']).date()).days
    if days_held > 365:
        recommendations.append("📅 Long-term position - consider tax implications")
    
    return recommendations if recommendations else ["✅ Position appears to be performing within normal parameters"]

if __name__ == "__main__":
    main()
