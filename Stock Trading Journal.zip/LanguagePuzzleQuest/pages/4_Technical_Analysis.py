import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
from utils.data_fetcher import DataFetcher
from utils.technical_indicators import TechnicalIndicators

st.set_page_config(
    page_title="Technical Analysis",
    page_icon="📊",
    layout="wide"
)

def main():
    st.title("📊 Technical Analysis")
    st.markdown("---")
    
    # Sidebar controls
    with st.sidebar:
        st.header("🎯 Analysis Parameters")
        
        # Symbol input
        symbol = st.text_input("Stock Symbol:", value="AAPL", key="tech_symbol").upper()
        
        # Time period
        period = st.selectbox("Time Period:", 
                            ["1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y"],
                            index=5)
        
        # Interval
        interval = st.selectbox("Interval:", 
                              ["1m", "5m", "15m", "30m", "1h", "1d"],
                              index=5)
        
        st.markdown("---")
        
        # Technical indicators selection
        st.subheader("📈 Technical Indicators")
        
        show_sma = st.checkbox("Simple Moving Average", value=True)
        if show_sma:
            sma_period = st.slider("SMA Period:", 5, 200, 20)
        
        show_ema = st.checkbox("Exponential Moving Average", value=True)
        if show_ema:
            ema_period = st.slider("EMA Period:", 5, 200, 12)
        
        show_bollinger = st.checkbox("Bollinger Bands", value=True)
        if show_bollinger:
            bb_period = st.slider("BB Period:", 10, 50, 20)
            bb_std = st.slider("BB Std Dev:", 1.0, 3.0, 2.0, 0.1)
        
        show_rsi = st.checkbox("RSI", value=True)
        if show_rsi:
            rsi_period = st.slider("RSI Period:", 5, 30, 14)
        
        show_macd = st.checkbox("MACD", value=True)
        
        show_volume = st.checkbox("Volume Analysis", value=True)
        
        st.markdown("---")
        
        # Signal generation
        st.subheader("🎯 Signal Generation")
        signal_sensitivity = st.slider("Signal Sensitivity:", 1, 10, 5)
        
        # Pattern recognition
        st.subheader("📊 Pattern Recognition")
        detect_patterns = st.checkbox("Detect Chart Patterns", value=True)
        
        # Support/Resistance
        show_support_resistance = st.checkbox("Support/Resistance Levels", value=True)
    
    # Main content
    data_fetcher = DataFetcher()
    tech_indicators = TechnicalIndicators()
    
    try:
        # Get stock data
        stock_data = data_fetcher.get_stock_data(symbol, period=period, interval=interval)
        
        if stock_data is not None and not stock_data.empty:
            # Current price and basic info
            current_price = stock_data['Close'].iloc[-1]
            price_change = stock_data['Close'].iloc[-1] - stock_data['Close'].iloc[-2]
            price_change_pct = (price_change / stock_data['Close'].iloc[-2]) * 100
            
            # Display key metrics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Current Price", f"${current_price:.2f}", f"{price_change:.2f} ({price_change_pct:.1f}%)")
            with col2:
                st.metric("Volume", f"{stock_data['Volume'].iloc[-1]:,}")
            with col3:
                volatility = stock_data['Close'].pct_change().std() * np.sqrt(252)
                st.metric("Volatility", f"{volatility:.1%}")
            with col4:
                high_52w = stock_data['High'].rolling(window=252).max().iloc[-1]
                st.metric("52W High", f"${high_52w:.2f}")
            
            # Calculate technical indicators
            indicators = {}
            
            if show_sma:
                indicators['SMA'] = tech_indicators.sma(stock_data['Close'], sma_period)
            
            if show_ema:
                indicators['EMA'] = tech_indicators.ema(stock_data['Close'], ema_period)
            
            if show_bollinger:
                bb = tech_indicators.bollinger_bands(stock_data['Close'], bb_period, bb_std)
                indicators['BB_Upper'] = bb['upper']
                indicators['BB_Middle'] = bb['middle']
                indicators['BB_Lower'] = bb['lower']
            
            if show_rsi:
                indicators['RSI'] = tech_indicators.rsi(stock_data['Close'], rsi_period)
            
            if show_macd:
                macd = tech_indicators.macd(stock_data['Close'])
                indicators['MACD'] = macd['macd']
                indicators['MACD_Signal'] = macd['signal']
                indicators['MACD_Histogram'] = macd['histogram']
            
            # Main price chart
            st.subheader(f"📈 {symbol} Price Chart")
            
            fig = create_price_chart(stock_data, indicators, symbol)
            st.plotly_chart(fig, use_container_width=True)
            
            # Technical indicators dashboard
            st.markdown("---")
            st.subheader("📊 Technical Indicators Dashboard")
            
            # Create tabs for different indicator categories
            tab1, tab2, tab3, tab4 = st.tabs(["📈 Trend", "📊 Momentum", "📉 Volatility", "🎯 Signals"])
            
            with tab1:
                # Trend indicators
                trend_col1, trend_col2 = st.columns(2)
                
                with trend_col1:
                    if show_sma and 'SMA' in indicators:
                        current_sma = indicators['SMA'].iloc[-1]
                        sma_trend = "Bullish" if current_price > current_sma else "Bearish"
                        st.metric(f"SMA ({sma_period})", f"${current_sma:.2f}", sma_trend)
                    
                    if show_ema and 'EMA' in indicators:
                        current_ema = indicators['EMA'].iloc[-1]
                        ema_trend = "Bullish" if current_price > current_ema else "Bearish"
                        st.metric(f"EMA ({ema_period})", f"${current_ema:.2f}", ema_trend)
                
                with trend_col2:
                    # Trend strength
                    if show_sma and 'SMA' in indicators:
                        trend_strength = abs(current_price - current_sma) / current_sma * 100
                        st.metric("Trend Strength", f"{trend_strength:.1f}%")
                    
                    # Moving average convergence/divergence
                    if show_sma and show_ema and 'SMA' in indicators and 'EMA' in indicators:
                        ma_convergence = "Converging" if abs(current_sma - current_ema) < abs(indicators['SMA'].iloc[-2] - indicators['EMA'].iloc[-2]) else "Diverging"
                        st.metric("MA Relationship", ma_convergence)
                
                # Trend analysis chart
                if show_sma or show_ema:
                    trend_fig = create_trend_chart(stock_data, indicators, symbol)
                    st.plotly_chart(trend_fig, use_container_width=True)
            
            with tab2:
                # Momentum indicators
                momentum_col1, momentum_col2 = st.columns(2)
                
                with momentum_col1:
                    if show_rsi and 'RSI' in indicators:
                        current_rsi = indicators['RSI'].iloc[-1]
                        rsi_signal = "Overbought" if current_rsi > 70 else "Oversold" if current_rsi < 30 else "Neutral"
                        st.metric(f"RSI ({rsi_period})", f"{current_rsi:.1f}", rsi_signal)
                    
                    if show_macd and 'MACD' in indicators:
                        current_macd = indicators['MACD'].iloc[-1]
                        macd_signal = "Bullish" if current_macd > indicators['MACD_Signal'].iloc[-1] else "Bearish"
                        st.metric("MACD", f"{current_macd:.3f}", macd_signal)
                
                with momentum_col2:
                    # Momentum strength
                    price_momentum = (stock_data['Close'].iloc[-1] / stock_data['Close'].iloc[-10] - 1) * 100
                    st.metric("10-Day Momentum", f"{price_momentum:.1f}%")
                    
                    # Volume momentum
                    volume_momentum = (stock_data['Volume'].iloc[-5:].mean() / stock_data['Volume'].iloc[-20:-5].mean() - 1) * 100
                    st.metric("Volume Momentum", f"{volume_momentum:.1f}%")
                
                # Momentum charts
                if show_rsi or show_macd:
                    momentum_fig = create_momentum_chart(indicators, symbol)
                    st.plotly_chart(momentum_fig, use_container_width=True)
            
            with tab3:
                # Volatility indicators
                volatility_col1, volatility_col2 = st.columns(2)
                
                with volatility_col1:
                    if show_bollinger and 'BB_Upper' in indicators:
                        bb_position = (current_price - indicators['BB_Lower'].iloc[-1]) / (indicators['BB_Upper'].iloc[-1] - indicators['BB_Lower'].iloc[-1])
                        bb_signal = "Near Upper" if bb_position > 0.8 else "Near Lower" if bb_position < 0.2 else "Middle"
                        st.metric("Bollinger Band Position", f"{bb_position:.1%}", bb_signal)
                    
                    # Average True Range
                    atr = tech_indicators.atr(stock_data)
                    current_atr = atr.iloc[-1]
                    st.metric("ATR", f"${current_atr:.2f}")
                
                with volatility_col2:
                    # Volatility metrics
                    realized_vol = stock_data['Close'].pct_change().rolling(20).std() * np.sqrt(252)
                    current_vol = realized_vol.iloc[-1]
                    st.metric("20-Day Volatility", f"{current_vol:.1%}")
                    
                    # Volatility trend
                    vol_trend = "Increasing" if current_vol > realized_vol.iloc[-5:].mean() else "Decreasing"
                    st.metric("Volatility Trend", vol_trend)
                
                # Volatility chart
                if show_bollinger:
                    volatility_fig = create_volatility_chart(stock_data, indicators, symbol)
                    st.plotly_chart(volatility_fig, use_container_width=True)
            
            with tab4:
                # Trading signals
                st.subheader("🎯 Trading Signals")
                
                # Generate signals
                signals = generate_trading_signals(stock_data, indicators, signal_sensitivity)
                
                # Display signals
                signal_col1, signal_col2 = st.columns(2)
                
                with signal_col1:
                    st.write("**Buy Signals:**")
                    buy_signals = [s for s in signals if s['type'] == 'BUY']
                    for signal in buy_signals:
                        st.write(f"🟢 {signal['indicator']}: {signal['description']}")
                
                with signal_col2:
                    st.write("**Sell Signals:**")
                    sell_signals = [s for s in signals if s['type'] == 'SELL']
                    for signal in sell_signals:
                        st.write(f"🔴 {signal['indicator']}: {signal['description']}")
                
                # Signal strength
                signal_strength = len(buy_signals) - len(sell_signals)
                if signal_strength > 0:
                    st.success(f"Overall Signal: BULLISH (Strength: {signal_strength})")
                elif signal_strength < 0:
                    st.error(f"Overall Signal: BEARISH (Strength: {abs(signal_strength)})")
                else:
                    st.info("Overall Signal: NEUTRAL")
                
                # Signal history chart
                signal_fig = create_signal_chart(stock_data, signals, symbol)
                st.plotly_chart(signal_fig, use_container_width=True)
            
            # Pattern recognition
            if detect_patterns:
                st.markdown("---")
                st.subheader("🔍 Chart Pattern Recognition")
                
                patterns = detect_chart_patterns(stock_data)
                
                if patterns:
                    for pattern in patterns:
                        st.write(f"📊 **{pattern['name']}**: {pattern['description']}")
                        st.write(f"   Reliability: {pattern['reliability']}")
                        st.write(f"   Target: {pattern['target']}")
                else:
                    st.info("No significant chart patterns detected.")
            
            # Support and resistance levels
            if show_support_resistance:
                st.markdown("---")
                st.subheader("📏 Support & Resistance Levels")
                
                support_resistance = calculate_support_resistance(stock_data)
                
                sr_col1, sr_col2 = st.columns(2)
                
                with sr_col1:
                    st.write("**Support Levels:**")
                    for level in support_resistance['support']:
                        distance = (current_price - level) / current_price * 100
                        st.write(f"${level:.2f} ({distance:+.1f}%)")
                
                with sr_col2:
                    st.write("**Resistance Levels:**")
                    for level in support_resistance['resistance']:
                        distance = (level - current_price) / current_price * 100
                        st.write(f"${level:.2f} (+{distance:.1f}%)")
        
        else:
            st.error(f"Could not fetch data for {symbol}. Please check the symbol and try again.")
    
    except Exception as e:
        st.error(f"Error in technical analysis: {str(e)}")

def create_price_chart(stock_data, indicators, symbol):
    """Create the main price chart with technical indicators"""
    fig = go.Figure()
    
    # Add candlestick chart
    fig.add_trace(go.Candlestick(
        x=stock_data.index,
        open=stock_data['Open'],
        high=stock_data['High'],
        low=stock_data['Low'],
        close=stock_data['Close'],
        name=symbol,
        increasing_line_color='green',
        decreasing_line_color='red'
    ))
    
    # Add technical indicators
    for indicator, data in indicators.items():
        if indicator in ['SMA', 'EMA']:
            fig.add_trace(go.Scatter(
                x=stock_data.index,
                y=data,
                mode='lines',
                name=indicator,
                line=dict(width=2)
            ))
        elif indicator.startswith('BB_'):
            color = 'blue' if 'Upper' in indicator else 'red' if 'Lower' in indicator else 'orange'
            fig.add_trace(go.Scatter(
                x=stock_data.index,
                y=data,
                mode='lines',
                name=indicator,
                line=dict(color=color, width=1),
                opacity=0.7
            ))
    
    fig.update_layout(
        title=f'{symbol} Price Chart with Technical Indicators',
        xaxis_title='Date',
        yaxis_title='Price ($)',
        height=600,
        xaxis_rangeslider_visible=False
    )
    
    return fig

def create_trend_chart(stock_data, indicators, symbol):
    """Create trend analysis chart"""
    fig = go.Figure()
    
    # Add price
    fig.add_trace(go.Scatter(
        x=stock_data.index,
        y=stock_data['Close'],
        mode='lines',
        name='Price',
        line=dict(color='blue', width=2)
    ))
    
    # Add moving averages
    for indicator, data in indicators.items():
        if indicator in ['SMA', 'EMA']:
            fig.add_trace(go.Scatter(
                x=stock_data.index,
                y=data,
                mode='lines',
                name=indicator,
                line=dict(width=2)
            ))
    
    fig.update_layout(
        title=f'{symbol} Trend Analysis',
        xaxis_title='Date',
        yaxis_title='Price ($)',
        height=400
    )
    
    return fig

def create_momentum_chart(indicators, symbol):
    """Create momentum indicators chart"""
    fig = go.Figure()
    
    if 'RSI' in indicators:
        fig.add_trace(go.Scatter(
            x=indicators['RSI'].index,
            y=indicators['RSI'],
            mode='lines',
            name='RSI',
            line=dict(color='purple', width=2)
        ))
        
        # Add RSI levels
        fig.add_hline(y=70, line_dash="dash", line_color="red", annotation_text="Overbought")
        fig.add_hline(y=30, line_dash="dash", line_color="green", annotation_text="Oversold")
    
    fig.update_layout(
        title=f'{symbol} Momentum Indicators',
        xaxis_title='Date',
        yaxis_title='RSI',
        height=400
    )
    
    return fig

def create_volatility_chart(stock_data, indicators, symbol):
    """Create volatility chart with Bollinger Bands"""
    fig = go.Figure()
    
    # Add price
    fig.add_trace(go.Scatter(
        x=stock_data.index,
        y=stock_data['Close'],
        mode='lines',
        name='Price',
        line=dict(color='blue', width=2)
    ))
    
    # Add Bollinger Bands
    if 'BB_Upper' in indicators:
        fig.add_trace(go.Scatter(
            x=stock_data.index,
            y=indicators['BB_Upper'],
            mode='lines',
            name='BB Upper',
            line=dict(color='red', width=1),
            fill=None
        ))
        
        fig.add_trace(go.Scatter(
            x=stock_data.index,
            y=indicators['BB_Lower'],
            mode='lines',
            name='BB Lower',
            line=dict(color='red', width=1),
            fill='tonexty',
            fillcolor='rgba(255, 0, 0, 0.1)'
        ))
        
        fig.add_trace(go.Scatter(
            x=stock_data.index,
            y=indicators['BB_Middle'],
            mode='lines',
            name='BB Middle',
            line=dict(color='orange', width=1)
        ))
    
    fig.update_layout(
        title=f'{symbol} Volatility Analysis',
        xaxis_title='Date',
        yaxis_title='Price ($)',
        height=400
    )
    
    return fig

def create_signal_chart(stock_data, signals, symbol):
    """Create chart with trading signals"""
    fig = go.Figure()
    
    # Add price
    fig.add_trace(go.Scatter(
        x=stock_data.index,
        y=stock_data['Close'],
        mode='lines',
        name='Price',
        line=dict(color='blue', width=2)
    ))
    
    # Add signals (simplified - would need actual signal timestamps)
    # This is a placeholder for signal visualization
    
    fig.update_layout(
        title=f'{symbol} Trading Signals',
        xaxis_title='Date',
        yaxis_title='Price ($)',
        height=400
    )
    
    return fig

def generate_trading_signals(stock_data, indicators, sensitivity):
    """Generate trading signals based on technical indicators"""
    signals = []
    
    current_price = stock_data['Close'].iloc[-1]
    
    # SMA signals
    if 'SMA' in indicators:
        current_sma = indicators['SMA'].iloc[-1]
        if current_price > current_sma:
            signals.append({
                'type': 'BUY',
                'indicator': 'SMA',
                'description': f'Price above SMA ({current_sma:.2f})',
                'strength': sensitivity
            })
        else:
            signals.append({
                'type': 'SELL',
                'indicator': 'SMA',
                'description': f'Price below SMA ({current_sma:.2f})',
                'strength': sensitivity
            })
    
    # RSI signals
    if 'RSI' in indicators:
        current_rsi = indicators['RSI'].iloc[-1]
        if current_rsi < 30:
            signals.append({
                'type': 'BUY',
                'indicator': 'RSI',
                'description': f'RSI oversold ({current_rsi:.1f})',
                'strength': sensitivity * 1.5
            })
        elif current_rsi > 70:
            signals.append({
                'type': 'SELL',
                'indicator': 'RSI',
                'description': f'RSI overbought ({current_rsi:.1f})',
                'strength': sensitivity * 1.5
            })
    
    # MACD signals
    if 'MACD' in indicators and 'MACD_Signal' in indicators:
        current_macd = indicators['MACD'].iloc[-1]
        current_signal = indicators['MACD_Signal'].iloc[-1]
        
        if current_macd > current_signal:
            signals.append({
                'type': 'BUY',
                'indicator': 'MACD',
                'description': 'MACD above signal line',
                'strength': sensitivity
            })
        else:
            signals.append({
                'type': 'SELL',
                'indicator': 'MACD',
                'description': 'MACD below signal line',
                'strength': sensitivity
            })
    
    # Bollinger Bands signals
    if 'BB_Upper' in indicators and 'BB_Lower' in indicators:
        bb_upper = indicators['BB_Upper'].iloc[-1]
        bb_lower = indicators['BB_Lower'].iloc[-1]
        
        if current_price <= bb_lower:
            signals.append({
                'type': 'BUY',
                'indicator': 'Bollinger Bands',
                'description': 'Price at lower band',
                'strength': sensitivity
            })
        elif current_price >= bb_upper:
            signals.append({
                'type': 'SELL',
                'indicator': 'Bollinger Bands',
                'description': 'Price at upper band',
                'strength': sensitivity
            })
    
    return signals

def detect_chart_patterns(stock_data):
    """Detect common chart patterns"""
    patterns = []
    
    # Simple pattern detection (in practice, this would be more sophisticated)
    prices = stock_data['Close'].values
    
    # Double bottom detection (simplified)
    if len(prices) >= 20:
        recent_lows = []
        for i in range(10, len(prices) - 10):
            if prices[i] == min(prices[i-10:i+10]):
                recent_lows.append((i, prices[i]))
        
        if len(recent_lows) >= 2:
            patterns.append({
                'name': 'Double Bottom',
                'description': 'Potential reversal pattern detected',
                'reliability': 'Medium',
                'target': f'${prices[-1] * 1.05:.2f}'
            })
    
    return patterns

def calculate_support_resistance(stock_data):
    """Calculate support and resistance levels"""
    prices = stock_data['Close'].values
    
    # Simple support/resistance calculation
    support_levels = []
    resistance_levels = []
    
    # Find recent highs and lows
    for i in range(5, len(prices) - 5):
        if prices[i] == max(prices[i-5:i+5]):
            resistance_levels.append(prices[i])
        elif prices[i] == min(prices[i-5:i+5]):
            support_levels.append(prices[i])
    
    # Remove duplicates and sort
    support_levels = sorted(list(set(support_levels)))[-3:]  # Top 3 support levels
    resistance_levels = sorted(list(set(resistance_levels)), reverse=True)[:3]  # Top 3 resistance levels
    
    return {
        'support': support_levels,
        'resistance': resistance_levels
    }

if __name__ == "__main__":
    main()
