import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import yfinance as yf
from utils.data_fetcher import DataFetcher
from utils.risk_management import RiskManager
from utils.technical_indicators import TechnicalIndicators

st.set_page_config(
    page_title="Backtesting Engine",
    page_icon="⚡",
    layout="wide"
)

def main():
    st.title("⚡ Advanced Backtesting Engine")
    st.markdown("---")
    
    # Initialize session state for backtesting results
    if 'backtest_results' not in st.session_state:
        st.session_state.backtest_results = None
    if 'trade_history' not in st.session_state:
        st.session_state.trade_history = pd.DataFrame()
    
    # Sidebar for strategy configuration
    with st.sidebar:
        st.header("🎯 Strategy Configuration")
        
        # Symbol selection
        symbol = st.text_input("Symbol:", value="AAPL", key="backtest_symbol").upper()
        
        # Time period
        start_date = st.date_input("Start Date:", value=datetime.now() - timedelta(days=365))
        end_date = st.date_input("End Date:", value=datetime.now())
        
        # Initial capital
        initial_capital = st.number_input("Initial Capital ($):", min_value=1000.0, value=100000.0, step=1000.0)
        
        st.markdown("---")
        
        # Strategy type
        st.subheader("📈 Strategy Type")
        strategy_type = st.selectbox("Select Strategy:", [
            "Moving Average Crossover",
            "RSI Mean Reversion", 
            "Bollinger Band Squeeze",
            "MACD Signal",
            "Custom Strategy"
        ])
        
        # Strategy parameters based on type
        if strategy_type == "Moving Average Crossover":
            fast_ma = st.slider("Fast MA Period:", 5, 50, 10)
            slow_ma = st.slider("Slow MA Period:", 20, 200, 50)
            
        elif strategy_type == "RSI Mean Reversion":
            rsi_period = st.slider("RSI Period:", 5, 30, 14)
            rsi_oversold = st.slider("RSI Oversold:", 10, 40, 30)
            rsi_overbought = st.slider("RSI Overbought:", 60, 90, 70)
            
        elif strategy_type == "Bollinger Band Squeeze":
            bb_period = st.slider("BB Period:", 10, 50, 20)
            bb_std = st.slider("BB Std Dev:", 1.0, 3.0, 2.0, 0.1)
            
        elif strategy_type == "MACD Signal":
            macd_fast = st.slider("MACD Fast:", 5, 20, 12)
            macd_slow = st.slider("MACD Slow:", 20, 50, 26)
            macd_signal = st.slider("MACD Signal:", 5, 15, 9)
        
        st.markdown("---")
        
        # Risk management
        st.subheader("🛡️ Risk Management")
        stop_loss_pct = st.slider("Stop Loss (%):", 1.0, 20.0, 5.0, 0.5)
        take_profit_pct = st.slider("Take Profit (%):", 5.0, 50.0, 15.0, 0.5)
        position_size_pct = st.slider("Position Size (%):", 10.0, 100.0, 25.0, 5.0)
        
        # Commission and slippage
        commission = st.number_input("Commission per Trade ($):", min_value=0.0, value=1.0, step=0.1)
        slippage_pct = st.number_input("Slippage (%):", min_value=0.0, value=0.1, step=0.01)
        
        st.markdown("---")
        
        # Run backtest button
        if st.button("🚀 Run Backtest", type="primary"):
            with st.spinner("Running backtest..."):
                results = run_backtest(
                    symbol, start_date, end_date, initial_capital,
                    strategy_type, locals(), stop_loss_pct, take_profit_pct,
                    position_size_pct, commission, slippage_pct
                )
                st.session_state.backtest_results = results
                st.success("Backtest completed!")
                st.rerun()
    
    # Main content area
    if st.session_state.backtest_results is not None:
        results = st.session_state.backtest_results
        
        # Performance overview
        st.subheader("📊 Performance Overview")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_return = ((results['portfolio_value'].iloc[-1] / initial_capital) - 1) * 100
            st.metric("Total Return", f"{total_return:.2f}%")
        
        with col2:
            sharpe_ratio = calculate_sharpe_ratio(results['returns'])
            st.metric("Sharpe Ratio", f"{sharpe_ratio:.2f}")
        
        with col3:
            max_drawdown = calculate_max_drawdown(results['portfolio_value'])
            st.metric("Max Drawdown", f"{max_drawdown:.2f}%")
        
        with col4:
            win_rate = results['win_rate']
            st.metric("Win Rate", f"{win_rate:.1f}%")
        
        # Performance chart
        st.subheader("📈 Equity Curve")
        
        fig = go.Figure()
        
        # Portfolio value
        fig.add_trace(go.Scatter(
            x=results['dates'],
            y=results['portfolio_value'],
            mode='lines',
            name='Portfolio Value',
            line=dict(color='blue', width=2)
        ))
        
        # Buy and hold comparison
        buy_hold_value = results['buy_hold_value']
        fig.add_trace(go.Scatter(
            x=results['dates'],
            y=buy_hold_value,
            mode='lines',
            name='Buy & Hold',
            line=dict(color='gray', width=1, dash='dash')
        ))
        
        # Add trade markers
        trade_data = results.get('trades', pd.DataFrame())
        if not trade_data.empty:
            # Buy signals
            buys = trade_data[trade_data['action'] == 'BUY']
            if not buys.empty:
                fig.add_trace(go.Scatter(
                    x=buys['date'],
                    y=buys['portfolio_value'],
                    mode='markers',
                    name='Buy',
                    marker=dict(color='green', size=10, symbol='triangle-up')
                ))
            
            # Sell signals
            sells = trade_data[trade_data['action'] == 'SELL']
            if not sells.empty:
                fig.add_trace(go.Scatter(
                    x=sells['date'],
                    y=sells['portfolio_value'],
                    mode='markers',
                    name='Sell',
                    marker=dict(color='red', size=10, symbol='triangle-down')
                ))
        
        fig.update_layout(
            title=f'{symbol} Backtest Results',
            xaxis_title='Date',
            yaxis_title='Portfolio Value ($)',
            height=500,
            hovermode='x unified'
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Detailed metrics
        st.subheader("📋 Detailed Metrics")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Performance Metrics**")
            metrics_df = pd.DataFrame({
                'Metric': [
                    'Total Return', 'Annualized Return', 'Volatility',
                    'Sharpe Ratio', 'Sortino Ratio', 'Max Drawdown',
                    'Calmar Ratio', 'Win Rate', 'Profit Factor'
                ],
                'Value': [
                    f"{total_return:.2f}%",
                    f"{results.get('annual_return', 0):.2f}%",
                    f"{results.get('volatility', 0):.2f}%",
                    f"{sharpe_ratio:.2f}",
                    f"{results.get('sortino_ratio', 0):.2f}",
                    f"{max_drawdown:.2f}%",
                    f"{results.get('calmar_ratio', 0):.2f}",
                    f"{win_rate:.1f}%",
                    f"{results.get('profit_factor', 0):.2f}"
                ]
            })
            st.dataframe(metrics_df, use_container_width=True)
        
        with col2:
            st.write("**Trade Statistics**")
            trade_stats_df = pd.DataFrame({
                'Statistic': [
                    'Total Trades', 'Winning Trades', 'Losing Trades',
                    'Average Win', 'Average Loss', 'Best Trade',
                    'Worst Trade', 'Average Trade', 'Expectancy'
                ],
                'Value': [
                    f"{results.get('total_trades', 0)}",
                    f"{results.get('winning_trades', 0)}",
                    f"{results.get('losing_trades', 0)}",
                    f"${results.get('avg_win', 0):.2f}",
                    f"${results.get('avg_loss', 0):.2f}",
                    f"${results.get('best_trade', 0):.2f}",
                    f"${results.get('worst_trade', 0):.2f}",
                    f"${results.get('avg_trade', 0):.2f}",
                    f"${results.get('expectancy', 0):.2f}"
                ]
            })
            st.dataframe(trade_stats_df, use_container_width=True)
        
        # Trade history
        if not trade_data.empty:
            st.subheader("📝 Trade History")
            
            # Format trade data for display
            display_trades = trade_data.copy()
            display_trades['date'] = pd.to_datetime(display_trades['date']).dt.strftime('%Y-%m-%d')
            display_trades['price'] = display_trades['price'].apply(lambda x: f"${x:.2f}")
            display_trades['pnl'] = display_trades['pnl'].apply(lambda x: f"${x:.2f}")
            
            st.dataframe(display_trades, use_container_width=True)
        
        # Monthly returns heatmap
        st.subheader("🗓️ Monthly Returns Heatmap")
        monthly_returns = calculate_monthly_returns(results['returns'], results['dates'])
        
        if not monthly_returns.empty:
            fig_heatmap = px.imshow(
                monthly_returns.values,
                x=monthly_returns.columns,
                y=monthly_returns.index,
                color_continuous_scale='RdYlGn',
                aspect='auto',
                title='Monthly Returns (%)'
            )
            
            # Add text annotations
            for i in range(len(monthly_returns.index)):
                for j in range(len(monthly_returns.columns)):
                    fig_heatmap.add_annotation(
                        x=j, y=i,
                        text=f"{monthly_returns.iloc[i, j]:.1f}%",
                        showarrow=False,
                        font=dict(color='black' if abs(monthly_returns.iloc[i, j]) < 5 else 'white')
                    )
            
            st.plotly_chart(fig_heatmap, use_container_width=True)
        
        # Export results
        st.subheader("💾 Export Results")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Export Trade History"):
                csv = trade_data.to_csv(index=False)
                st.download_button(
                    label="Download CSV",
                    data=csv,
                    file_name=f"{symbol}_trade_history_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
        
        with col2:
            if st.button("Export Performance Report"):
                report = generate_performance_report(results, symbol)
                st.download_button(
                    label="Download Report",
                    data=report,
                    file_name=f"{symbol}_backtest_report_{datetime.now().strftime('%Y%m%d')}.txt",
                    mime="text/plain"
                )
    
    else:
        # Welcome message
        st.info("📊 Configure your strategy parameters in the sidebar and click 'Run Backtest' to begin.")
        
        # Strategy explanation
        st.subheader("📚 Available Strategies")
        
        strategy_info = {
            "Moving Average Crossover": "Buy when fast MA crosses above slow MA, sell when it crosses below.",
            "RSI Mean Reversion": "Buy when RSI is oversold, sell when overbought.",
            "Bollinger Band Squeeze": "Trade breakouts from Bollinger Band compression.",
            "MACD Signal": "Trade based on MACD line crossing signal line.",
            "Custom Strategy": "Define your own entry and exit rules."
        }
        
        for strategy, description in strategy_info.items():
            st.write(f"**{strategy}**: {description}")

def run_backtest(symbol, start_date, end_date, initial_capital, strategy_type, params, 
                stop_loss_pct, take_profit_pct, position_size_pct, commission, slippage_pct):
    """Run the backtest with specified parameters"""
    
    # Fetch data
    data_fetcher = DataFetcher()
    tech_indicators = TechnicalIndicators()
    
    # Get historical data
    data = data_fetcher.get_stock_data(symbol, period='2y')
    if data is None or data.empty:
        return None
    
    # Filter by date range
    data = data[(data.index >= pd.Timestamp(start_date)) & (data.index <= pd.Timestamp(end_date))]
    
    if len(data) < 50:  # Need sufficient data
        return None
    
    # Calculate indicators based on strategy
    if strategy_type == "Moving Average Crossover":
        data['fast_ma'] = tech_indicators.sma(data['Close'], params['fast_ma'])
        data['slow_ma'] = tech_indicators.sma(data['Close'], params['slow_ma'])
        
    elif strategy_type == "RSI Mean Reversion":
        data['rsi'] = tech_indicators.rsi(data['Close'], params['rsi_period'])
        
    elif strategy_type == "Bollinger Band Squeeze":
        bb = tech_indicators.bollinger_bands(data['Close'], params['bb_period'], params['bb_std'])
        data['bb_upper'] = bb['upper']
        data['bb_middle'] = bb['middle']
        data['bb_lower'] = bb['lower']
        
    elif strategy_type == "MACD Signal":
        macd = tech_indicators.macd(data['Close'], params['macd_fast'], params['macd_slow'], params['macd_signal'])
        data['macd'] = macd['macd']
        data['macd_signal'] = macd['signal']
    
    # Initialize tracking variables
    portfolio_value = initial_capital
    cash = initial_capital
    position = 0
    entry_price = 0
    entry_date = None
    
    portfolio_values = []
    dates = []
    trades = []
    returns = []
    
    # Buy and hold comparison
    initial_price = data['Close'].iloc[0]
    buy_hold_shares = initial_capital / initial_price
    buy_hold_values = []
    
    for i, (date, row) in enumerate(data.iterrows()):
        current_price = row['Close']
        
        # Calculate buy and hold value
        buy_hold_value = buy_hold_shares * current_price
        buy_hold_values.append(buy_hold_value)
        
        # Generate signals based on strategy
        buy_signal = False
        sell_signal = False
        
        if i < 50:  # Skip first 50 days for indicator warmup
            portfolio_values.append(portfolio_value)
            dates.append(date)
            if len(portfolio_values) > 1:
                returns.append((portfolio_value / portfolio_values[-2]) - 1)
            else:
                returns.append(0)
            continue
        
        if strategy_type == "Moving Average Crossover":
            if (data['fast_ma'].iloc[i] > data['slow_ma'].iloc[i] and 
                data['fast_ma'].iloc[i-1] <= data['slow_ma'].iloc[i-1]):
                buy_signal = True
            elif (data['fast_ma'].iloc[i] < data['slow_ma'].iloc[i] and 
                  data['fast_ma'].iloc[i-1] >= data['slow_ma'].iloc[i-1]):
                sell_signal = True
                
        elif strategy_type == "RSI Mean Reversion":
            if data['rsi'].iloc[i] < params['rsi_oversold'] and position == 0:
                buy_signal = True
            elif data['rsi'].iloc[i] > params['rsi_overbought'] and position > 0:
                sell_signal = True
                
        elif strategy_type == "Bollinger Band Squeeze":
            if (current_price < data['bb_lower'].iloc[i] and position == 0):
                buy_signal = True
            elif (current_price > data['bb_upper'].iloc[i] and position > 0):
                sell_signal = True
                
        elif strategy_type == "MACD Signal":
            if (data['macd'].iloc[i] > data['macd_signal'].iloc[i] and 
                data['macd'].iloc[i-1] <= data['macd_signal'].iloc[i-1]):
                buy_signal = True
            elif (data['macd'].iloc[i] < data['macd_signal'].iloc[i] and 
                  data['macd'].iloc[i-1] >= data['macd_signal'].iloc[i-1]):
                sell_signal = True
        
        # Execute trades
        if buy_signal and position == 0:
            # Calculate position size
            position_value = portfolio_value * (position_size_pct / 100)
            shares_to_buy = int(position_value / (current_price * (1 + slippage_pct / 100)))
            
            if shares_to_buy > 0:
                cost = shares_to_buy * current_price * (1 + slippage_pct / 100) + commission
                
                if cost <= cash:
                    position = shares_to_buy
                    entry_price = current_price * (1 + slippage_pct / 100)
                    entry_date = date
                    cash -= cost
                    
                    trades.append({
                        'date': date,
                        'action': 'BUY',
                        'price': entry_price,
                        'shares': shares_to_buy,
                        'portfolio_value': portfolio_value,
                        'pnl': 0
                    })
        
        elif (sell_signal or (position > 0 and check_stop_loss_take_profit(
                current_price, entry_price, stop_loss_pct, take_profit_pct))) and position > 0:
            
            # Sell position
            sale_proceeds = position * current_price * (1 - slippage_pct / 100) - commission
            cash += sale_proceeds
            
            # Calculate P&L
            pnl = sale_proceeds - (position * entry_price + commission)
            
            trades.append({
                'date': date,
                'action': 'SELL',
                'price': current_price,
                'shares': position,
                'portfolio_value': portfolio_value,
                'pnl': pnl
            })
            
            position = 0
            entry_price = 0
            entry_date = None
        
        # Update portfolio value
        if position > 0:
            portfolio_value = cash + position * current_price
        else:
            portfolio_value = cash
        
        portfolio_values.append(portfolio_value)
        dates.append(date)
        
        # Calculate returns
        if len(portfolio_values) > 1:
            returns.append((portfolio_value / portfolio_values[-2]) - 1)
        else:
            returns.append(0)
    
    # Calculate performance metrics
    trades_df = pd.DataFrame(trades)
    
    # Trade statistics
    if not trades_df.empty:
        pnl_trades = trades_df[trades_df['action'] == 'SELL']['pnl']
        winning_trades = len(pnl_trades[pnl_trades > 0])
        losing_trades = len(pnl_trades[pnl_trades < 0])
        total_trades = len(pnl_trades)
        win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
        
        avg_win = pnl_trades[pnl_trades > 0].mean() if winning_trades > 0 else 0
        avg_loss = pnl_trades[pnl_trades < 0].mean() if losing_trades > 0 else 0
        best_trade = pnl_trades.max() if not pnl_trades.empty else 0
        worst_trade = pnl_trades.min() if not pnl_trades.empty else 0
        avg_trade = pnl_trades.mean() if not pnl_trades.empty else 0
        
        profit_factor = abs(avg_win * winning_trades / (avg_loss * losing_trades)) if losing_trades > 0 and avg_loss != 0 else 0
        expectancy = (win_rate/100 * avg_win) - ((1-win_rate/100) * abs(avg_loss))
    else:
        winning_trades = losing_trades = total_trades = 0
        win_rate = avg_win = avg_loss = best_trade = worst_trade = avg_trade = profit_factor = expectancy = 0
    
    # Performance metrics
    annual_return = calculate_annual_return(returns)
    volatility = np.std(returns) * np.sqrt(252) * 100
    sortino_ratio = calculate_sortino_ratio(returns)
    calmar_ratio = annual_return / abs(calculate_max_drawdown(portfolio_values)) if calculate_max_drawdown(portfolio_values) != 0 else 0
    
    return {
        'portfolio_value': portfolio_values,
        'buy_hold_value': buy_hold_values,
        'dates': dates,
        'returns': returns,
        'trades': trades_df,
        'win_rate': win_rate,
        'total_trades': total_trades,
        'winning_trades': winning_trades,
        'losing_trades': losing_trades,
        'avg_win': avg_win,
        'avg_loss': avg_loss,
        'best_trade': best_trade,
        'worst_trade': worst_trade,
        'avg_trade': avg_trade,
        'profit_factor': profit_factor,
        'expectancy': expectancy,
        'annual_return': annual_return,
        'volatility': volatility,
        'sortino_ratio': sortino_ratio,
        'calmar_ratio': calmar_ratio
    }

def check_stop_loss_take_profit(current_price, entry_price, stop_loss_pct, take_profit_pct):
    """Check if stop loss or take profit should be triggered"""
    if entry_price == 0:
        return False
    
    price_change_pct = (current_price - entry_price) / entry_price * 100
    
    if price_change_pct <= -stop_loss_pct:  # Stop loss
        return True
    elif price_change_pct >= take_profit_pct:  # Take profit
        return True
    
    return False

def calculate_sharpe_ratio(returns):
    """Calculate Sharpe ratio"""
    if len(returns) == 0:
        return 0
    
    excess_returns = np.array(returns)
    if np.std(excess_returns) == 0:
        return 0
    
    return np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)

def calculate_max_drawdown(portfolio_values):
    """Calculate maximum drawdown"""
    if len(portfolio_values) == 0:
        return 0
    
    portfolio_series = pd.Series(portfolio_values)
    peak = portfolio_series.expanding().max()
    drawdown = (portfolio_series - peak) / peak * 100
    return drawdown.min()

def calculate_annual_return(returns):
    """Calculate annualized return"""
    if len(returns) == 0:
        return 0
    
    total_return = np.prod([1 + r for r in returns]) - 1
    years = len(returns) / 252
    
    if years <= 0:
        return 0
    
    return (1 + total_return) ** (1/years) - 1

def calculate_sortino_ratio(returns):
    """Calculate Sortino ratio"""
    if len(returns) == 0:
        return 0
    
    downside_returns = [r for r in returns if r < 0]
    if len(downside_returns) == 0:
        return float('inf') if np.mean(returns) > 0 else 0
    
    downside_std = np.std(downside_returns) * np.sqrt(252)
    if downside_std == 0:
        return 0
    
    return np.mean(returns) * 252 / downside_std

def calculate_monthly_returns(returns, dates):
    """Calculate monthly returns for heatmap"""
    if len(returns) == 0 or len(dates) == 0:
        return pd.DataFrame()
    
    df = pd.DataFrame({'date': dates[1:], 'return': returns[1:]})
    df['date'] = pd.to_datetime(df['date'])
    df.set_index('date', inplace=True)
    
    monthly_returns = df['return'].resample('M').apply(lambda x: (1 + x).prod() - 1) * 100
    
    monthly_returns_pivot = monthly_returns.groupby([
        monthly_returns.index.year,
        monthly_returns.index.month
    ]).first().unstack()
    
    monthly_returns_pivot.columns = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                   'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    
    return monthly_returns_pivot.fillna(0)

def generate_performance_report(results, symbol):
    """Generate a text performance report"""
    report = f"""
BACKTEST PERFORMANCE REPORT
Symbol: {symbol}
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

PERFORMANCE SUMMARY
Total Return: {((results['portfolio_value'][-1] / results['portfolio_value'][0]) - 1) * 100:.2f}%
Annualized Return: {results.get('annual_return', 0):.2f}%
Volatility: {results.get('volatility', 0):.2f}%
Sharpe Ratio: {calculate_sharpe_ratio(results['returns']):.2f}
Sortino Ratio: {results.get('sortino_ratio', 0):.2f}
Maximum Drawdown: {calculate_max_drawdown(results['portfolio_value']):.2f}%
Calmar Ratio: {results.get('calmar_ratio', 0):.2f}

TRADE STATISTICS
Total Trades: {results.get('total_trades', 0)}
Winning Trades: {results.get('winning_trades', 0)}
Losing Trades: {results.get('losing_trades', 0)}
Win Rate: {results.get('win_rate', 0):.1f}%
Average Win: ${results.get('avg_win', 0):.2f}
Average Loss: ${results.get('avg_loss', 0):.2f}
Best Trade: ${results.get('best_trade', 0):.2f}
Worst Trade: ${results.get('worst_trade', 0):.2f}
Profit Factor: {results.get('profit_factor', 0):.2f}
Expectancy: ${results.get('expectancy', 0):.2f}

RISK METRICS
Beta: N/A
Alpha: N/A
Information Ratio: N/A
Tracking Error: N/A
"""
    return report

if __name__ == "__main__":
    main()