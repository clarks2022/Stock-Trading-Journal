import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import calendar

st.set_page_config(
    page_title="Performance Tracker",
    page_icon="📈",
    layout="wide"
)

def main():
    st.title("📈 Performance Tracker & Analytics")
    st.markdown("---")
    
    # Initialize session state
    if 'trading_journal' not in st.session_state:
        st.session_state.trading_journal = pd.DataFrame(columns=[
            'Date', 'Symbol', 'Action', 'Quantity', 'Price', 'Commission', 'P&L', 
            'Strategy', 'Setup', 'Emotion', 'Confidence', 'Notes', 'Tag'
        ])
    
    # Sidebar for journal entry
    with st.sidebar:
        st.header("📝 Add Trade Entry")
        
        with st.form("trade_entry"):
            trade_date = st.date_input("Date:", value=datetime.now().date())
            symbol = st.text_input("Symbol:", value="", placeholder="e.g., AAPL")
            action = st.selectbox("Action:", ["BUY", "SELL", "BUY_TO_OPEN", "SELL_TO_CLOSE"])
            quantity = st.number_input("Quantity:", min_value=1, value=100)
            price = st.number_input("Price ($):", min_value=0.01, value=100.0)
            commission = st.number_input("Commission ($):", min_value=0.0, value=1.0)
            
            # Strategy and setup
            strategy = st.selectbox("Strategy:", [
                "Scalping", "Day Trading", "Swing Trading", "Position Trading",
                "Options Strategy", "Momentum", "Mean Reversion", "Breakout", "Other"
            ])
            
            setup = st.selectbox("Setup:", [
                "Bull Flag", "Bear Flag", "Breakout", "Pullback", "Support/Resistance",
                "Moving Average", "MACD Signal", "RSI Divergence", "Earnings Play", "Other"
            ])
            
            # Psychological factors
            emotion = st.selectbox("Emotion Before Trade:", [
                "Confident", "Neutral", "Anxious", "FOMO", "Revenge", "Greedy", "Fearful"
            ])
            
            confidence = st.slider("Confidence Level (1-10):", 1, 10, 7)
            
            # Notes and tags
            notes = st.text_area("Trade Notes:", placeholder="Reasoning, market conditions, etc.")
            tag = st.selectbox("Tag:", ["A+ Setup", "A Setup", "B Setup", "C Setup", "Mistake"])
            
            # Calculate P&L (simplified)
            if action in ["SELL", "SELL_TO_CLOSE"]:
                # For sells, you'd typically calculate against the buy price
                # This is simplified - in reality you'd track position history
                pnl = st.number_input("P&L ($):", value=0.0, help="Enter the profit/loss for this trade")
            else:
                pnl = 0.0
            
            submit_trade = st.form_submit_button("Add Trade", type="primary")
        
        if submit_trade and symbol:
            new_trade = pd.DataFrame({
                'Date': [trade_date],
                'Symbol': [symbol.upper()],
                'Action': [action],
                'Quantity': [quantity],
                'Price': [price],
                'Commission': [commission],
                'P&L': [pnl],
                'Strategy': [strategy],
                'Setup': [setup],
                'Emotion': [emotion],
                'Confidence': [confidence],
                'Notes': [notes],
                'Tag': [tag]
            })
            
            st.session_state.trading_journal = pd.concat([
                st.session_state.trading_journal, new_trade
            ], ignore_index=True)
            
            st.success(f"Trade added: {action} {quantity} {symbol}")
            st.rerun()
        
        st.markdown("---")
        
        # Quick stats
        if not st.session_state.trading_journal.empty:
            total_pnl = st.session_state.trading_journal['P&L'].sum()
            total_trades = len(st.session_state.trading_journal)
            
            st.metric("Total P&L", f"${total_pnl:.2f}")
            st.metric("Total Trades", total_trades)
    
    # Main content area
    if not st.session_state.trading_journal.empty:
        journal_df = st.session_state.trading_journal.copy()
        journal_df['Date'] = pd.to_datetime(journal_df['Date'])
        
        # Performance overview
        st.subheader("🎯 Performance Overview")
        
        # Key metrics
        total_pnl = journal_df['P&L'].sum()
        winning_trades = len(journal_df[journal_df['P&L'] > 0])
        losing_trades = len(journal_df[journal_df['P&L'] < 0])
        total_trades = len(journal_df)
        win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
        
        avg_win = journal_df[journal_df['P&L'] > 0]['P&L'].mean() if winning_trades > 0 else 0
        avg_loss = journal_df[journal_df['P&L'] < 0]['P&L'].mean() if losing_trades > 0 else 0
        profit_factor = abs(avg_win * winning_trades / (avg_loss * losing_trades)) if losing_trades > 0 and avg_loss != 0 else float('inf')
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric("Total P&L", f"${total_pnl:.2f}", delta=f"{total_pnl:.2f}")
        with col2:
            st.metric("Win Rate", f"{win_rate:.1f}%")
        with col3:
            st.metric("Total Trades", total_trades)
        with col4:
            st.metric("Avg Win", f"${avg_win:.2f}")
        with col5:
            st.metric("Avg Loss", f"${avg_loss:.2f}")
        
        # Performance charts
        st.subheader("📊 Performance Charts")
        
        tab1, tab2, tab3, tab4 = st.tabs(["📈 Equity Curve", "📅 Calendar", "🧠 Psychology", "📋 Analysis"])
        
        with tab1:
            # Equity curve
            journal_df_sorted = journal_df.sort_values('Date')
            journal_df_sorted['Cumulative_PnL'] = journal_df_sorted['P&L'].cumsum()
            
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=journal_df_sorted['Date'],
                y=journal_df_sorted['Cumulative_PnL'],
                mode='lines+markers',
                name='Cumulative P&L',
                line=dict(color='blue', width=2),
                marker=dict(size=6)
            ))
            
            # Add trade markers
            winning_trades_df = journal_df_sorted[journal_df_sorted['P&L'] > 0]
            losing_trades_df = journal_df_sorted[journal_df_sorted['P&L'] < 0]
            
            if not winning_trades_df.empty:
                fig.add_trace(go.Scatter(
                    x=winning_trades_df['Date'],
                    y=winning_trades_df['Cumulative_PnL'],
                    mode='markers',
                    name='Winning Trades',
                    marker=dict(color='green', size=10, symbol='triangle-up')
                ))
            
            if not losing_trades_df.empty:
                fig.add_trace(go.Scatter(
                    x=losing_trades_df['Date'],
                    y=losing_trades_df['Cumulative_PnL'],
                    mode='markers',
                    name='Losing Trades',
                    marker=dict(color='red', size=10, symbol='triangle-down')
                ))
            
            fig.update_layout(
                title='Trading Performance - Equity Curve',
                xaxis_title='Date',
                yaxis_title='Cumulative P&L ($)',
                height=500,
                hovermode='x unified'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Monthly performance
            st.subheader("📅 Monthly Performance")
            
            journal_df_sorted['Month'] = journal_df_sorted['Date'].dt.to_period('M')
            monthly_pnl = journal_df_sorted.groupby('Month')['P&L'].sum().reset_index()
            monthly_pnl['Month_Name'] = monthly_pnl['Month'].dt.strftime('%Y-%m')
            
            fig_monthly = px.bar(
                monthly_pnl,
                x='Month_Name',
                y='P&L',
                title='Monthly P&L',
                color='P&L',
                color_continuous_scale='RdYlGn'
            )
            
            st.plotly_chart(fig_monthly, use_container_width=True)
        
        with tab2:
            # Trading calendar heatmap
            st.subheader("🗓️ Trading Calendar")
            
            # Create calendar data
            journal_df['WeekDay'] = journal_df['Date'].dt.day_name()
            journal_df['Hour'] = journal_df['Date'].dt.hour
            
            # Day of week performance
            weekday_pnl = journal_df.groupby('WeekDay')['P&L'].agg(['sum', 'count', 'mean']).reset_index()
            weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
            weekday_pnl['WeekDay'] = pd.Categorical(weekday_pnl['WeekDay'], categories=weekday_order, ordered=True)
            weekday_pnl = weekday_pnl.sort_values('WeekDay')
            
            col1, col2 = st.columns(2)
            
            with col1:
                fig_weekday = px.bar(
                    weekday_pnl,
                    x='WeekDay',
                    y='sum',
                    title='P&L by Day of Week',
                    color='sum',
                    color_continuous_scale='RdYlGn'
                )
                st.plotly_chart(fig_weekday, use_container_width=True)
            
            with col2:
                fig_trades_count = px.bar(
                    weekday_pnl,
                    x='WeekDay',
                    y='count',
                    title='Number of Trades by Day',
                    color='count',
                    color_continuous_scale='Blues'
                )
                st.plotly_chart(fig_trades_count, use_container_width=True)
            
            # Best and worst trading days
            st.subheader("🏆 Best & Worst Days")
            
            best_days = journal_df.nlargest(5, 'P&L')[['Date', 'Symbol', 'P&L', 'Strategy', 'Setup']]
            worst_days = journal_df.nsmallest(5, 'P&L')[['Date', 'Symbol', 'P&L', 'Strategy', 'Setup']]
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**🟢 Best Trading Days**")
                st.dataframe(best_days, use_container_width=True)
            
            with col2:
                st.write("**🔴 Worst Trading Days**")
                st.dataframe(worst_days, use_container_width=True)
        
        with tab3:
            # Psychology analysis
            st.subheader("🧠 Trading Psychology Analysis")
            
            # Emotion vs Performance
            emotion_analysis = journal_df.groupby('Emotion')['P&L'].agg(['sum', 'count', 'mean']).reset_index()
            
            col1, col2 = st.columns(2)
            
            with col1:
                fig_emotion = px.bar(
                    emotion_analysis,
                    x='Emotion',
                    y='sum',
                    title='Total P&L by Emotion',
                    color='sum',
                    color_continuous_scale='RdYlGn'
                )
                fig_emotion.update_xaxis(tickangle=45)
                st.plotly_chart(fig_emotion, use_container_width=True)
            
            with col2:
                fig_emotion_avg = px.bar(
                    emotion_analysis,
                    x='Emotion',
                    y='mean',
                    title='Average P&L by Emotion',
                    color='mean',
                    color_continuous_scale='RdYlGn'
                )
                fig_emotion_avg.update_xaxis(tickangle=45)
                st.plotly_chart(fig_emotion_avg, use_container_width=True)
            
            # Confidence vs Performance
            confidence_analysis = journal_df.groupby('Confidence')['P&L'].agg(['sum', 'count', 'mean']).reset_index()
            
            fig_confidence = px.scatter(
                journal_df,
                x='Confidence',
                y='P&L',
                color='Emotion',
                size='Quantity',
                title='Confidence vs P&L',
                hover_data=['Symbol', 'Strategy']
            )
            st.plotly_chart(fig_confidence, use_container_width=True)
            
            # Psychology insights
            st.subheader("💡 Psychology Insights")
            
            # Calculate insights
            best_emotion = emotion_analysis.loc[emotion_analysis['sum'].idxmax(), 'Emotion']
            worst_emotion = emotion_analysis.loc[emotion_analysis['sum'].idxmin(), 'Emotion']
            
            high_confidence_trades = journal_df[journal_df['Confidence'] >= 8]['P&L'].mean()
            low_confidence_trades = journal_df[journal_df['Confidence'] <= 4]['P&L'].mean()
            
            insights = [
                f"🎯 Your best performing emotion is **{best_emotion}** with total P&L of ${emotion_analysis.loc[emotion_analysis['Emotion'] == best_emotion, 'sum'].iloc[0]:.2f}",
                f"⚠️ Your worst performing emotion is **{worst_emotion}** with total P&L of ${emotion_analysis.loc[emotion_analysis['Emotion'] == worst_emotion, 'sum'].iloc[0]:.2f}",
                f"📈 High confidence trades (8-10) average: ${high_confidence_trades:.2f}",
                f"📉 Low confidence trades (1-4) average: ${low_confidence_trades:.2f}",
                f"🎲 Your win rate is {win_rate:.1f}% - {'Above average!' if win_rate > 50 else 'Focus on risk management'}",
                f"💰 Your profit factor is {profit_factor:.2f} - {'Excellent!' if profit_factor > 2 else 'Good!' if profit_factor > 1.5 else 'Needs improvement'}"
            ]
            
            for insight in insights:
                st.write(insight)
        
        with tab4:
            # Detailed analysis
            st.subheader("📊 Strategy & Setup Analysis")
            
            # Strategy performance
            strategy_analysis = journal_df.groupby('Strategy')['P&L'].agg(['sum', 'count', 'mean']).reset_index()
            setup_analysis = journal_df.groupby('Setup')['P&L'].agg(['sum', 'count', 'mean']).reset_index()
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Strategy Performance**")
                st.dataframe(strategy_analysis.round(2), use_container_width=True)
                
                fig_strategy = px.pie(
                    strategy_analysis,
                    values='count',
                    names='Strategy',
                    title='Trades by Strategy'
                )
                st.plotly_chart(fig_strategy, use_container_width=True)
            
            with col2:
                st.write("**Setup Performance**")
                st.dataframe(setup_analysis.round(2), use_container_width=True)
                
                fig_setup = px.bar(
                    setup_analysis,
                    x='Setup',
                    y='sum',
                    title='P&L by Setup',
                    color='sum',
                    color_continuous_scale='RdYlGn'
                )
                fig_setup.update_xaxis(tickangle=45)
                st.plotly_chart(fig_setup, use_container_width=True)
            
            # Tag analysis
            st.subheader("🏷️ Trade Quality Analysis")
            
            tag_analysis = journal_df.groupby('Tag')['P&L'].agg(['sum', 'count', 'mean']).reset_index()
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Performance by Trade Quality**")
                st.dataframe(tag_analysis.round(2), use_container_width=True)
            
            with col2:
                fig_tag = px.bar(
                    tag_analysis,
                    x='Tag',
                    y='mean',
                    title='Average P&L by Trade Quality',
                    color='mean',
                    color_continuous_scale='RdYlGn'
                )
                st.plotly_chart(fig_tag, use_container_width=True)
        
        # Trading journal table
        st.subheader("📝 Trading Journal")
        
        # Filters
        col1, col2, col3 = st.columns(3)
        
        with col1:
            symbol_filter = st.multiselect("Filter by Symbol:", journal_df['Symbol'].unique())
        with col2:
            strategy_filter = st.multiselect("Filter by Strategy:", journal_df['Strategy'].unique())
        with col3:
            date_range = st.date_input("Date Range:", 
                                     value=[journal_df['Date'].min().date(), journal_df['Date'].max().date()],
                                     help="Select start and end dates")
        
        # Apply filters
        filtered_df = journal_df.copy()
        
        if symbol_filter:
            filtered_df = filtered_df[filtered_df['Symbol'].isin(symbol_filter)]
        if strategy_filter:
            filtered_df = filtered_df[filtered_df['Strategy'].isin(strategy_filter)]
        if len(date_range) == 2:
            filtered_df = filtered_df[
                (filtered_df['Date'].dt.date >= date_range[0]) & 
                (filtered_df['Date'].dt.date <= date_range[1])
            ]
        
        # Display filtered data
        display_df = filtered_df.copy()
        display_df['Date'] = display_df['Date'].dt.strftime('%Y-%m-%d')
        display_df['P&L'] = display_df['P&L'].apply(lambda x: f"${x:.2f}")
        display_df['Price'] = display_df['Price'].apply(lambda x: f"${x:.2f}")
        
        st.dataframe(display_df, use_container_width=True)
        
        # Export functionality
        st.subheader("💾 Export Data")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Export Filtered Data"):
                csv = filtered_df.to_csv(index=False)
                st.download_button(
                    label="Download CSV",
                    data=csv,
                    file_name=f"trading_journal_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
        
        with col2:
            if st.button("Export Performance Report"):
                report = generate_performance_report(journal_df)
                st.download_button(
                    label="Download Report",
                    data=report,
                    file_name=f"performance_report_{datetime.now().strftime('%Y%m%d')}.txt",
                    mime="text/plain"
                )
    
    else:
        # Welcome message
        st.info("📊 Start by adding your first trade in the sidebar to begin tracking your performance!")
        
        # Sample data option
        if st.button("Load Sample Data", type="primary"):
            sample_data = create_sample_trading_data()
            st.session_state.trading_journal = sample_data
            st.success("Sample trading data loaded!")
            st.rerun()

def create_sample_trading_data():
    """Create sample trading data for demonstration"""
    dates = pd.date_range(start='2024-01-01', end='2024-07-01', freq='D')
    symbols = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'NVDA', 'AMZN']
    strategies = ['Scalping', 'Day Trading', 'Swing Trading', 'Momentum']
    setups = ['Breakout', 'Pullback', 'Support/Resistance', 'Moving Average']
    emotions = ['Confident', 'Neutral', 'Anxious', 'FOMO', 'Greedy']
    tags = ['A+ Setup', 'A Setup', 'B Setup', 'C Setup', 'Mistake']
    
    sample_trades = []
    
    for i in range(50):  # Generate 50 sample trades
        date = np.random.choice(dates)
        symbol = np.random.choice(symbols)
        action = np.random.choice(['BUY', 'SELL'])
        quantity = np.random.randint(10, 200)
        price = np.random.uniform(50, 300)
        commission = 1.0
        pnl = np.random.normal(10, 50)  # Random P&L with mean=10, std=50
        strategy = np.random.choice(strategies)
        setup = np.random.choice(setups)
        emotion = np.random.choice(emotions)
        confidence = np.random.randint(3, 10)
        tag = np.random.choice(tags)
        
        sample_trades.append({
            'Date': pd.Timestamp(date).date(),
            'Symbol': symbol,
            'Action': action,
            'Quantity': quantity,
            'Price': price,
            'Commission': commission,
            'P&L': pnl,
            'Strategy': strategy,
            'Setup': setup,
            'Emotion': emotion,
            'Confidence': confidence,
            'Notes': f"Sample trade for {symbol}",
            'Tag': tag
        })
    
    return pd.DataFrame(sample_trades)

def generate_performance_report(journal_df):
    """Generate a comprehensive performance report"""
    total_pnl = journal_df['P&L'].sum()
    total_trades = len(journal_df)
    winning_trades = len(journal_df[journal_df['P&L'] > 0])
    losing_trades = len(journal_df[journal_df['P&L'] < 0])
    win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
    
    avg_win = journal_df[journal_df['P&L'] > 0]['P&L'].mean() if winning_trades > 0 else 0
    avg_loss = journal_df[journal_df['P&L'] < 0]['P&L'].mean() if losing_trades > 0 else 0
    
    best_trade = journal_df['P&L'].max()
    worst_trade = journal_df['P&L'].min()
    
    profit_factor = abs(avg_win * winning_trades / (avg_loss * losing_trades)) if losing_trades > 0 and avg_loss != 0 else float('inf')
    
    report = f"""
TRADING PERFORMANCE REPORT
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

SUMMARY STATISTICS
Total P&L: ${total_pnl:.2f}
Total Trades: {total_trades}
Winning Trades: {winning_trades}
Losing Trades: {losing_trades}
Win Rate: {win_rate:.1f}%

TRADE METRICS
Average Win: ${avg_win:.2f}
Average Loss: ${avg_loss:.2f}
Best Trade: ${best_trade:.2f}
Worst Trade: ${worst_trade:.2f}
Profit Factor: {profit_factor:.2f}

STRATEGY BREAKDOWN
{journal_df.groupby('Strategy')['P&L'].agg(['sum', 'count', 'mean']).to_string()}

SETUP ANALYSIS
{journal_df.groupby('Setup')['P&L'].agg(['sum', 'count', 'mean']).to_string()}

PSYCHOLOGY ANALYSIS
{journal_df.groupby('Emotion')['P&L'].agg(['sum', 'count', 'mean']).to_string()}

TRADE QUALITY
{journal_df.groupby('Tag')['P&L'].agg(['sum', 'count', 'mean']).to_string()}
"""
    
    return report

if __name__ == "__main__":
    main()