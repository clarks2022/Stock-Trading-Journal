import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
import json

st.set_page_config(
    page_title="AI Psychology Coach",
    page_icon="🧠",
    layout="wide"
)

def main():
    st.title("🧠 AI Trading Psychology Coach")
    st.markdown("---")
    
    # Initialize session state
    if 'psychology_chat_history' not in st.session_state:
        st.session_state.psychology_chat_history = []
    
    if 'psychology_assessment' not in st.session_state:
        st.session_state.psychology_assessment = {
            'risk_tolerance': None,
            'emotional_state': None,
            'trading_goals': None,
            'experience_level': None,
            'main_challenges': []
        }
    
    # Sidebar for quick assessment and settings
    with st.sidebar:
        st.header("🎯 Quick Psychology Assessment")
        
        # Quick assessment form
        with st.form("psychology_assessment_form"):
            st.write("**Help me understand your trading psychology:**")
            
            risk_tolerance = st.selectbox("Risk Tolerance:", [
                "Very Conservative", "Conservative", "Moderate", "Aggressive", "Very Aggressive"
            ], index=2)
            
            emotional_state = st.selectbox("Current Emotional State:", [
                "Confident", "Neutral", "Anxious", "Frustrated", "Euphoric", "Fearful", "Stressed"
            ], index=1)
            
            trading_goals = st.selectbox("Primary Trading Goal:", [
                "Consistent Income", "Wealth Building", "Learning/Education", 
                "Quick Profits", "Portfolio Diversification", "Retirement Planning"
            ])
            
            experience_level = st.selectbox("Experience Level:", [
                "Beginner (< 1 year)", "Intermediate (1-3 years)", 
                "Advanced (3-5 years)", "Expert (5+ years)"
            ])
            
            challenges = st.multiselect("Main Trading Challenges:", [
                "Fear of Missing Out (FOMO)", "Revenge Trading", "Overtrading",
                "Poor Risk Management", "Emotional Decision Making", "Lack of Discipline",
                "Analysis Paralysis", "Overconfidence", "Loss Aversion", "Impatience"
            ])
            
            submit_assessment = st.form_submit_button("Update Assessment", type="primary")
        
        if submit_assessment:
            st.session_state.psychology_assessment = {
                'risk_tolerance': risk_tolerance,
                'emotional_state': emotional_state,
                'trading_goals': trading_goals,
                'experience_level': experience_level,
                'main_challenges': challenges
            }
            st.success("Assessment updated!")
            st.rerun()
        
        st.markdown("---")
        
        # Psychology resources
        st.subheader("📚 Resources")
        
        resources = [
            "📖 Trading Psychology Books",
            "🧘 Meditation & Mindfulness",
            "📊 Emotional Trading Patterns",
            "🎯 Goal Setting Framework",
            "💪 Discipline Building Exercises"
        ]
        
        for resource in resources:
            if st.button(resource, key=f"resource_{resource}"):
                show_resource_content(resource)
        
        # Reset chat
        if st.button("🔄 Clear Chat History"):
            st.session_state.psychology_chat_history = []
            st.rerun()
    
    # Main chat interface
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("💬 AI Psychology Coach Chat")
        
        # Display chat history
        chat_container = st.container()
        
        with chat_container:
            for i, message in enumerate(st.session_state.psychology_chat_history):
                if message['role'] == 'user':
                    st.chat_message("user").write(message['content'])
                else:
                    st.chat_message("assistant").write(message['content'])
        
        # Chat input
        user_input = st.chat_input("Ask me about your trading psychology, emotions, or strategies...")
        
        if user_input:
            # Add user message to history
            st.session_state.psychology_chat_history.append({
                'role': 'user',
                'content': user_input,
                'timestamp': datetime.now()
            })
            
            # Generate AI response
            ai_response = generate_psychology_response(
                user_input, 
                st.session_state.psychology_assessment,
                st.session_state.psychology_chat_history
            )
            
            # Add AI response to history
            st.session_state.psychology_chat_history.append({
                'role': 'assistant',
                'content': ai_response,
                'timestamp': datetime.now()
            })
            
            st.rerun()
        
        # Suggested conversation starters
        if not st.session_state.psychology_chat_history:
            st.subheader("💡 Conversation Starters")
            
            starters = [
                "I keep making impulsive trades when I see big moves",
                "How can I overcome fear of taking losses?",
                "I tend to revenge trade after losses",
                "Help me develop better trading discipline",
                "I'm struggling with position sizing anxiety",
                "How do I handle FOMO in volatile markets?"
            ]
            
            cols = st.columns(2)
            for i, starter in enumerate(starters):
                with cols[i % 2]:
                    if st.button(starter, key=f"starter_{i}"):
                        # Simulate user input
                        st.session_state.psychology_chat_history.append({
                            'role': 'user',
                            'content': starter,
                            'timestamp': datetime.now()
                        })
                        
                        ai_response = generate_psychology_response(
                            starter,
                            st.session_state.psychology_assessment,
                            st.session_state.psychology_chat_history
                        )
                        
                        st.session_state.psychology_chat_history.append({
                            'role': 'assistant',
                            'content': ai_response,
                            'timestamp': datetime.now()
                        })
                        
                        st.rerun()
    
    with col2:
        st.subheader("📊 Psychology Dashboard")
        
        # Current assessment display
        assessment = st.session_state.psychology_assessment
        
        if assessment['emotional_state']:
            st.metric("Current Emotion", assessment['emotional_state'])
            
            # Emotion-based advice
            emotion_advice = get_emotion_advice(assessment['emotional_state'])
            st.info(emotion_advice)
        
        if assessment['risk_tolerance']:
            st.metric("Risk Tolerance", assessment['risk_tolerance'])
        
        if assessment['main_challenges']:
            st.write("**Main Challenges:**")
            for challenge in assessment['main_challenges']:
                st.write(f"• {challenge}")
        
        # Trading psychology tips
        st.subheader("💡 Daily Psychology Tips")
        
        daily_tips = [
            "🧘 Take 5 deep breaths before entering any trade",
            "📝 Write down your reasoning before each trade",
            "⏰ Set specific trading hours and stick to them",
            "🎯 Focus on process over profits",
            "📊 Review your emotional state after each trade",
            "🚫 Never trade when angry or euphoric",
            "💪 Practice position sizing discipline",
            "📈 Celebrate small wins and learn from losses"
        ]
        
        # Show a random tip
        import random
        today_tip = random.choice(daily_tips)
        st.success(today_tip)
        
        # Psychology score (simplified)
        if assessment['emotional_state'] and assessment['risk_tolerance']:
            psychology_score = calculate_psychology_score(assessment)
            
            st.metric("Psychology Score", f"{psychology_score}/100")
            
            if psychology_score >= 80:
                st.success("Excellent psychological state for trading!")
            elif psychology_score >= 60:
                st.warning("Good state, but room for improvement")
            else:
                st.error("Consider taking a break or focusing on emotional regulation")
        
        # Mood tracker
        st.subheader("📈 Mood Tracker")
        
        if 'mood_history' not in st.session_state:
            st.session_state.mood_history = []
        
        # Quick mood entry
        mood_rating = st.slider("Rate your current trading mood (1-10):", 1, 10, 5, key="mood_slider")
        
        if st.button("Log Mood"):
            st.session_state.mood_history.append({
                'date': datetime.now().date(),
                'mood': mood_rating,
                'emotion': assessment['emotional_state']
            })
            st.success("Mood logged!")
        
        # Show mood trend
        if st.session_state.mood_history:
            mood_df = pd.DataFrame(st.session_state.mood_history)
            st.line_chart(mood_df.set_index('date')['mood'])

def generate_psychology_response(user_input, assessment, chat_history):
    """Generate AI response based on user input and assessment"""
    
    # This is a simplified AI response generator
    # In a real implementation, you would use an AI service like OpenAI GPT or Anthropic Claude
    
    user_lower = user_input.lower()
    
    # Analyze user input for keywords and emotions
    if any(word in user_lower for word in ['fomo', 'fear of missing', 'missing out']):
        response = generate_fomo_response(assessment)
    elif any(word in user_lower for word in ['revenge', 'angry', 'mad', 'frustrated']):
        response = generate_revenge_trading_response(assessment)
    elif any(word in user_lower for word in ['loss', 'losing', 'losses', 'afraid']):
        response = generate_loss_response(assessment)
    elif any(word in user_lower for word in ['discipline', 'control', 'impulsive']):
        response = generate_discipline_response(assessment)
    elif any(word in user_lower for word in ['position size', 'sizing', 'risk management']):
        response = generate_risk_management_response(assessment)
    elif any(word in user_lower for word in ['stress', 'stressed', 'anxiety', 'anxious']):
        response = generate_stress_response(assessment)
    elif any(word in user_lower for word in ['overconfident', 'confident', 'overtrading']):
        response = generate_overconfidence_response(assessment)
    elif any(word in user_lower for word in ['goal', 'goals', 'objective']):
        response = generate_goal_response(assessment)
    else:
        response = generate_general_response(user_input, assessment)
    
    return response

def generate_fomo_response(assessment):
    """Generate response for FOMO-related questions"""
    responses = [
        f"""FOMO is one of the most common trading psychology challenges. Given your {assessment.get('experience_level', 'current')} experience level, here's my advice:

🎯 **Immediate Actions:**
• Set up alerts instead of watching charts constantly
• Create a pre-defined trading plan with specific entry criteria
• Practice saying "I missed this one, next opportunity will come"

🧠 **Mindset Shift:**
• Remember: There are thousands of trading opportunities daily
• Quality over quantity - one good trade is better than five mediocre ones
• FOMO often leads to buying tops and selling bottoms

💪 **Practical Exercise:**
Tomorrow, identify 3 setups you feel FOMO about but don't trade. Track how they perform. You'll likely see that patience pays off.""",

        f"""I understand the FOMO struggle, especially with your {assessment.get('emotional_state', 'current')} emotional state. Let's work on this together:

🔍 **Root Cause Analysis:**
FOMO usually comes from:
• Fear of missing profits
• Comparison with others' trades
• Lack of confidence in your strategy

✅ **Practical Solutions:**
1. Create a "missed trade" journal - track what you didn't trade and why
2. Set specific market hours for trading
3. Practice meditation or breathing exercises before market open
4. Remember your trading goals: {assessment.get('trading_goals', 'consistent growth')}

Would you like me to help you create a specific anti-FOMO routine?"""
    ]
    
    import random
    return random.choice(responses)

def generate_revenge_trading_response(assessment):
    """Generate response for revenge trading"""
    return f"""Revenge trading is a dangerous psychological trap. Here's how to break the cycle:

🛑 **Immediate Stop Strategy:**
• Step away from the computer for at least 30 minutes after a loss
• Set a daily loss limit and stick to it religiously
• Use smaller position sizes when you feel emotional

🧠 **Psychological Reframe:**
• Losses are part of trading - even the best traders lose 40-50% of the time
• Your next trade should be based on analysis, not emotion
• Market doesn't owe you anything - it's neutral

💪 **Recovery Plan:**
Given your {assessment.get('risk_tolerance', 'moderate')} risk tolerance:
1. Reduce position size by 50% for the next 5 trades
2. Take a 1-day break after any loss exceeding 2% of account
3. Journal your emotions before each trade

The market will be here tomorrow. Your capital might not be if you revenge trade."""

def generate_loss_response(assessment):
    """Generate response for loss-related fears"""
    return f"""Fear of losses is natural but can be managed effectively:

🎯 **Reframe Losses:**
• Losses are the cost of doing business in trading
• Every successful trader has more losing trades than you might think
• A loss with a plan is better than a random win

📊 **Risk Management for Your Profile:**
Based on your {assessment.get('risk_tolerance', 'moderate')} risk tolerance:
• Never risk more than 1-2% per trade
• Set stop losses BEFORE entering positions
• Use position sizing calculators

🧠 **Mental Techniques:**
1. Practice visualization: See yourself taking a loss calmly
2. Pre-define your maximum daily loss
3. Celebrate good decision-making, regardless of outcome

Remember: Protecting capital is more important than making profits. You can't make money if you don't have money to trade with."""

def generate_discipline_response(assessment):
    """Generate response for discipline issues"""
    return f"""Building trading discipline is like building a muscle - it takes consistent practice:

🏗️ **Foundation Building:**
• Create a detailed trading plan and stick to it
• Set specific rules for entry, exit, and position sizing
• Practice saying "no" to trades that don't meet your criteria

⚡ **Discipline Techniques:**
1. Use checklists for every trade
2. Set alarms for position management
3. Track rule violations in a journal
4. Reward yourself for following your plan (not profits)

🎯 **For Your {assessment.get('experience_level', 'current')} Level:**
Start with just 3 simple rules:
• Only trade your best setups
• Always use stop losses
• Never risk more than 1% per trade

Master these before adding complexity. Discipline beats intelligence in trading."""

def generate_risk_management_response(assessment):
    """Generate response for risk management questions"""
    return f"""Risk management is the foundation of successful trading. Let's optimize yours:

📊 **Position Sizing for {assessment.get('risk_tolerance', 'Moderate')} Risk Tolerance:**
• Conservative: 0.5-1% risk per trade
• Moderate: 1-2% risk per trade  
• Aggressive: 2-3% risk per trade (maximum recommended)

🛡️ **Risk Management Rules:**
1. Always know your exit before you enter
2. Never move stop losses against you
3. Diversify across different strategies/timeframes
4. Never risk more than 10% of account in all open positions

💡 **Psychology Tip:**
Position sizing anxiety often comes from risking too much. Start smaller than you think you should. It's better to make smaller profits consistently than large profits sporadically.

Would you like help calculating proper position sizes for your account?"""

def generate_stress_response(assessment):
    """Generate response for stress and anxiety"""
    return f"""Trading stress is manageable with the right techniques:

🧘 **Immediate Stress Relief:**
• Deep breathing: 4 counts in, hold 4, out 4
• Step away from screens for 10 minutes
• Physical movement - walk, stretch, or exercise

🎯 **Stress Prevention:**
• Reduce position sizes to sleep-well levels
• Set profit targets and stick to them
• Create end-of-day routines to decompress

🔄 **Long-term Solutions:**
1. Regular exercise outside trading hours
2. Meditation or mindfulness practice
3. Maintain interests outside of trading
4. Connect with other traders for perspective

Given your {assessment.get('emotional_state', 'current')} state, consider taking a day off to reset. The market will be here when you're mentally ready."""

def generate_overconfidence_response(assessment):
    """Generate response for overconfidence issues"""
    return f"""Overconfidence can be as dangerous as fear in trading:

⚠️ **Warning Signs You're Overconfident:**
• Increasing position sizes after wins
• Skipping risk management rules
• Trading outside your proven strategy
• Feeling like you "can't lose"

🎯 **Reality Check Techniques:**
• Keep a detailed trading journal
• Track your win rate and average win/loss
• Review your worst trades monthly
• Stay humble - market can humble anyone quickly

📊 **Confidence vs Overconfidence:**
Healthy confidence: Following your plan consistently
Overconfidence: Thinking rules don't apply to you

For your {assessment.get('experience_level', 'current')} level, remember that even expert traders continuously learn and adapt. The moment you think you've "figured out" the market is usually when it teaches you a lesson."""

def generate_goal_response(assessment):
    """Generate response for goal-related questions"""
    user_goal = assessment.get('trading_goals', 'consistent income')
    
    return f"""Let's align your psychology with your goal of {user_goal}:

🎯 **Goal-Specific Mindset:**
For {user_goal}:
• Focus on process metrics, not just profits
• Set realistic monthly/weekly targets
• Celebrate consistency over big wins

📊 **Tracking Progress:**
• Weekly review of trades vs plan adherence
• Monthly assessment of emotional state
• Quarterly goal adjustment if needed

💪 **Psychology Alignment:**
Your current emotional state ({assessment.get('emotional_state', 'neutral')}) and risk tolerance ({assessment.get('risk_tolerance', 'moderate')}) should guide your approach.

Remember: Goals without proper psychology are just wishes. Let's make sure your mind is aligned with your objectives."""

def generate_general_response(user_input, assessment):
    """Generate general response"""
    return f"""I'm here to help with your trading psychology. Based on your profile:

📊 **Your Current State:**
• Emotional State: {assessment.get('emotional_state', 'Not specified')}
• Risk Tolerance: {assessment.get('risk_tolerance', 'Not specified')}
• Experience: {assessment.get('experience_level', 'Not specified')}
• Main Goal: {assessment.get('trading_goals', 'Not specified')}

🤔 **Your Question:** "{user_input}"

Could you be more specific about what aspect of trading psychology you'd like to explore? For example:
• Emotional challenges (fear, greed, FOMO)
• Risk management mindset
• Discipline and consistency
• Stress management
• Goal setting and motivation

I'm here to provide personalized advice based on your unique psychological profile."""

def get_emotion_advice(emotion):
    """Get advice based on current emotional state"""
    advice_map = {
        'Confident': "Great mindset! Stay grounded and stick to your plan. Confidence is good, overconfidence is dangerous.",
        'Neutral': "Perfect emotional state for trading. Use this clarity to make objective decisions.",
        'Anxious': "Consider reducing position sizes or taking a break. Anxiety can lead to poor decision-making.",
        'Frustrated': "Step away from the charts. Frustrated traders often revenge trade. Come back when calm.",
        'Euphoric': "Dangerous state for trading. Euphoria often precedes major mistakes. Stay disciplined.",
        'Fearful': "Fear can protect you from losses but also prevent you from taking good trades. Start small.",
        'Stressed': "High stress impacts decision-making. Consider meditation or physical exercise before trading."
    }
    
    return advice_map.get(emotion, "Monitor your emotional state closely. It greatly impacts trading performance.")

def calculate_psychology_score(assessment):
    """Calculate a simplified psychology score"""
    score = 50  # Base score
    
    # Adjust based on emotional state
    emotion_scores = {
        'Confident': 15, 'Neutral': 20, 'Anxious': -10,
        'Frustrated': -15, 'Euphoric': -10, 'Fearful': -5, 'Stressed': -10
    }
    score += emotion_scores.get(assessment.get('emotional_state'), 0)
    
    # Adjust based on risk tolerance
    if assessment.get('risk_tolerance') in ['Conservative', 'Moderate']:
        score += 10
    elif assessment.get('risk_tolerance') in ['Very Conservative', 'Very Aggressive']:
        score -= 5
    
    # Adjust based on challenges
    challenge_penalties = {
        'Fear of Missing Out (FOMO)': -5,
        'Revenge Trading': -10,
        'Overtrading': -8,
        'Poor Risk Management': -10,
        'Emotional Decision Making': -8
    }
    
    for challenge in assessment.get('main_challenges', []):
        score += challenge_penalties.get(challenge, -3)
    
    return max(0, min(100, score))

def show_resource_content(resource):
    """Show content for selected resource"""
    st.info(f"Resource content for {resource} would be displayed here. This could include articles, exercises, or interactive content.")

if __name__ == "__main__":
    main()