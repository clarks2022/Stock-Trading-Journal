# Stock Options Analysis & Risk Management Platform

## Overview

This is a comprehensive Streamlit-based financial analysis platform that provides stock options analysis, risk management, portfolio tracking, and technical analysis capabilities. The application is designed for traders and investors who need sophisticated tools for analyzing options positions and managing portfolio risk.

## System Architecture

The application follows a modular architecture with the following key components:

- **Frontend**: Streamlit multi-page application with interactive dashboards
- **Database Layer**: PostgreSQL database with SQLAlchemy ORM for persistent data storage
- **Data Layer**: Yahoo Finance API integration via yfinance library for real-time market data
- **Analysis Engine**: Custom utility modules for options pricing, risk management, and technical indicators
- **Visualization**: Plotly-based interactive charts and graphs

## Key Features

### Core Trading Analysis Tools
- **Options Chain Analysis**: Complete options data with Black-Scholes pricing and Greeks
- **Risk Management Dashboard**: Portfolio risk assessment, position sizing, and VaR calculations
- **Technical Analysis**: 20+ indicators including RSI, MACD, Bollinger Bands, and pattern recognition
- **Real-time Data**: Live market data from Yahoo Finance API

### Advanced Trading Tools
- **Backtesting Engine**: Comprehensive strategy testing similar to Tradezella with:
  - Multiple strategy types (MA crossover, RSI mean reversion, MACD signals)
  - Risk management controls (stop loss, take profit, position sizing)
  - Performance metrics (Sharpe ratio, Sortino ratio, maximum drawdown)
  - Trade-by-trade analysis and monthly return heatmaps
  
- **Performance Tracker**: Professional trading journal featuring:
  - Trade entry with emotional state and confidence tracking
  - Psychology analysis (emotion vs performance correlation)
  - Strategy and setup performance breakdown
  - Calendar view and best/worst trading days
  - Comprehensive performance reports

- **AI Psychology Coach**: Advanced trading psychology support with:
  - Real-time chat interface for psychology questions
  - Personalized assessment based on risk tolerance and emotional state
  - Emotion-based trading advice and stress management
  - Psychology score calculation and mood tracking
  - Conversation starters for common trading psychology issues

### Portfolio Management
- **Real-time Portfolio Tracking**: Position monitoring with P&L analysis
- **Risk Metrics**: Position-level risk analysis with volatility and VaR calculations
- **Performance Analytics**: Detailed position performance with recommendations

## Key Components

### 1. Main Application (`app.py`)
- Entry point for the Streamlit application
- Manages global state including portfolio and watchlist
- Provides symbol selection and navigation to all trading tools

### 2. Pages Structure
- **Options Analysis** (`pages/1_Options_Analysis.py`): Options pricing models and Greeks calculations
- **Risk Management** (`pages/2_Risk_Management.py`): Portfolio risk assessment and position sizing
- **Portfolio Tracker** (`pages/3_Portfolio_Tracker.py`): Real-time portfolio monitoring and P&L tracking
- **Technical Analysis** (`pages/4_Technical_Analysis.py`): Technical indicators and chart analysis
- **Backtesting Engine** (`pages/5_Backtesting.py`): Strategy backtesting similar to Tradezella with comprehensive performance metrics
- **Performance Tracker** (`pages/6_Performance_Tracker.py`): Trading journal with performance analytics and psychology tracking
- **AI Psychology Coach** (`pages/7_AI_Psychology_Coach.py`): AI-powered trading psychology assessment and coaching

### 3. Database Layer
- **Models** (`database/models.py`): SQLAlchemy ORM models for all data entities
- **Services** (`database/services.py`): Database service layer with CRUD operations
- **Initialization** (`database/__init__.py`): Database setup and configuration

### 4. Utility Modules
- **Data Fetcher** (`utils/data_fetcher.py`): Yahoo Finance API integration for stock and options data
- **Options Pricing** (`utils/options_pricing.py`): Black-Scholes model implementation with Greeks calculations
- **Risk Management** (`utils/risk_management.py`): Position sizing algorithms and risk metrics
- **Technical Indicators** (`utils/technical_indicators.py`): SMA, EMA, RSI, and other technical analysis tools

## Data Flow

1. **Data Ingestion**: Real-time market data fetched from Yahoo Finance API
2. **Processing**: Raw data processed through custom calculation engines
3. **Analysis**: Mathematical models applied for options pricing, risk assessment, and technical analysis
4. **Persistence**: User data (portfolio, trades, psychology assessments, backtests) stored in PostgreSQL database
5. **Visualization**: Results presented through interactive Plotly charts and Streamlit components
6. **State Management**: Session-based temporary data combined with persistent database storage

## External Dependencies

### Core Libraries
- **Streamlit**: Web application framework for the user interface
- **yfinance**: Yahoo Finance API wrapper for market data
- **pandas**: Data manipulation and analysis
- **numpy**: Numerical computing
- **plotly**: Interactive visualization library
- **scipy**: Scientific computing (for statistical functions in options pricing)

### Financial Models
- **Black-Scholes Model**: For options pricing and Greeks calculations
- **Risk Management Algorithms**: Position sizing methods including Kelly Criterion
- **Technical Indicators**: Moving averages, RSI, and other technical analysis tools

## Deployment Strategy

The application is designed for deployment on Replit with the following considerations:

1. **Environment**: Python 3.x environment with scientific computing libraries
2. **Dependencies**: All required packages listed in standard Python package managers
3. **Data Storage**: Session-based storage for portfolio and watchlist data
4. **API Integration**: Yahoo Finance API for real-time market data (no API key required)
5. **Scalability**: Stateless design allows for easy horizontal scaling

## Changelog

- July 05, 2025: Initial setup with core features
- July 05, 2025: Added advanced trading tools:
  - Backtesting Engine with multiple strategies and comprehensive metrics
  - Performance Tracker with trading journal and psychology analysis
  - AI Psychology Coach for trader mental health and performance optimization
  - Enhanced navigation with easy access to all tools
- July 05, 2025: Integrated PostgreSQL database for data persistence:
  - Complete database schema for users, portfolio positions, trades, psychology assessments, backtests, watchlists, and chat history
  - Database service layer with CRUD operations for all entities
  - Portfolio tracker now saves positions to persistent storage
  - Automatic database initialization and user management

## User Preferences

Preferred communication style: Simple, everyday language.