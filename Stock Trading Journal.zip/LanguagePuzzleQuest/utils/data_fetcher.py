import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class DataFetcher:
    """Utility class for fetching financial data using yfinance"""
    
    def __init__(self):
        pass
    
    def get_stock_data(self, symbol, period='1y', interval='1d'):
        """
        Fetch stock data from Yahoo Finance
        
        Parameters:
        symbol: Stock symbol (e.g., 'AAPL')
        period: Time period ('1d', '5d', '1mo', '3mo', '6mo', '1y', '2y', '5y', '10y', 'ytd', 'max')
        interval: Data interval ('1m', '2m', '5m', '15m', '30m', '60m', '90m', '1h', '1d', '5d', '1wk', '1mo', '3mo')
        """
        try:
            ticker = yf.Ticker(symbol)
            data = ticker.history(period=period, interval=interval)
            
            if data.empty:
                print(f"No data found for symbol: {symbol}")
                return None
            
            return data
            
        except Exception as e:
            print(f"Error fetching stock data for {symbol}: {e}")
            return None
    
    def get_options_data(self, symbol):
        """
        Fetch options data for a given symbol
        
        Parameters:
        symbol: Stock symbol (e.g., 'AAPL')
        
        Returns:
        Dictionary with expiration dates as keys and calls/puts data as values
        """
        try:
            ticker = yf.Ticker(symbol)
            
            # Get expiration dates
            expirations = ticker.options
            
            if not expirations:
                print(f"No options data found for symbol: {symbol}")
                return None
            
            options_data = {}
            
            # Get options data for each expiration date
            for exp_date in expirations[:5]:  # Limit to first 5 expiration dates
                try:
                    options_chain = ticker.option_chain(exp_date)
                    
                    options_data[exp_date] = {
                        'calls': options_chain.calls,
                        'puts': options_chain.puts
                    }
                    
                except Exception as e:
                    print(f"Error fetching options data for {symbol} expiration {exp_date}: {e}")
                    continue
            
            return options_data
            
        except Exception as e:
            print(f"Error fetching options data for {symbol}: {e}")
            return None
    
    def get_company_info(self, symbol):
        """
        Fetch company information
        
        Parameters:
        symbol: Stock symbol (e.g., 'AAPL')
        """
        try:
            ticker = yf.Ticker(symbol)
            info = ticker.info
            
            return info
            
        except Exception as e:
            print(f"Error fetching company info for {symbol}: {e}")
            return None
    
    def get_financial_statements(self, symbol):
        """
        Fetch financial statements (income statement, balance sheet, cash flow)
        
        Parameters:
        symbol: Stock symbol (e.g., 'AAPL')
        """
        try:
            ticker = yf.Ticker(symbol)
            
            financials = {
                'income_statement': ticker.financials,
                'balance_sheet': ticker.balance_sheet,
                'cash_flow': ticker.cashflow
            }
            
            return financials
            
        except Exception as e:
            print(f"Error fetching financial statements for {symbol}: {e}")
            return None
    
    def get_dividends(self, symbol):
        """
        Fetch dividend history
        
        Parameters:
        symbol: Stock symbol (e.g., 'AAPL')
        """
        try:
            ticker = yf.Ticker(symbol)
            dividends = ticker.dividends
            
            return dividends
            
        except Exception as e:
            print(f"Error fetching dividends for {symbol}: {e}")
            return None
    
    def get_splits(self, symbol):
        """
        Fetch stock splits history
        
        Parameters:
        symbol: Stock symbol (e.g., 'AAPL')
        """
        try:
            ticker = yf.Ticker(symbol)
            splits = ticker.splits
            
            return splits
            
        except Exception as e:
            print(f"Error fetching splits for {symbol}: {e}")
            return None
    
    def get_multiple_stocks(self, symbols, period='1y', interval='1d'):
        """
        Fetch data for multiple stocks
        
        Parameters:
        symbols: List of stock symbols
        period: Time period
        interval: Data interval
        """
        try:
            data = yf.download(symbols, period=period, interval=interval)
            
            if data.empty:
                print(f"No data found for symbols: {symbols}")
                return None
            
            return data
            
        except Exception as e:
            print(f"Error fetching data for multiple stocks: {e}")
            return None
    
    def get_market_data(self, symbols=['SPY', 'QQQ', 'DIA', 'VIX'], period='1y'):
        """
        Fetch market indices data
        
        Parameters:
        symbols: List of market symbols
        period: Time period
        """
        try:
            market_data = {}
            
            for symbol in symbols:
                data = self.get_stock_data(symbol, period=period)
                if data is not None:
                    market_data[symbol] = data
            
            return market_data
            
        except Exception as e:
            print(f"Error fetching market data: {e}")
            return None
    
    def get_earnings_calendar(self, symbol):
        """
        Fetch earnings calendar (if available)
        
        Parameters:
        symbol: Stock symbol (e.g., 'AAPL')
        """
        try:
            ticker = yf.Ticker(symbol)
            calendar = ticker.calendar
            
            return calendar
            
        except Exception as e:
            print(f"Error fetching earnings calendar for {symbol}: {e}")
            return None
    
    def get_analyst_recommendations(self, symbol):
        """
        Fetch analyst recommendations
        
        Parameters:
        symbol: Stock symbol (e.g., 'AAPL')
        """
        try:
            ticker = yf.Ticker(symbol)
            recommendations = ticker.recommendations
            
            return recommendations
            
        except Exception as e:
            print(f"Error fetching analyst recommendations for {symbol}: {e}")
            return None
    
    def get_institutional_holders(self, symbol):
        """
        Fetch institutional holders data
        
        Parameters:
        symbol: Stock symbol (e.g., 'AAPL')
        """
        try:
            ticker = yf.Ticker(symbol)
            holders = ticker.institutional_holders
            
            return holders
            
        except Exception as e:
            print(f"Error fetching institutional holders for {symbol}: {e}")
            return None
    
    def get_realtime_price(self, symbol):
        """
        Fetch real-time price data
        
        Parameters:
        symbol: Stock symbol (e.g., 'AAPL')
        """
        try:
            ticker = yf.Ticker(symbol)
            
            # Get the most recent data
            data = ticker.history(period='1d', interval='1m')
            
            if data.empty:
                return None
            
            latest_data = data.iloc[-1]
            
            price_info = {
                'symbol': symbol,
                'price': latest_data['Close'],
                'volume': latest_data['Volume'],
                'high': latest_data['High'],
                'low': latest_data['Low'],
                'timestamp': data.index[-1]
            }
            
            return price_info
            
        except Exception as e:
            print(f"Error fetching real-time price for {symbol}: {e}")
            return None
    
    def calculate_technical_indicators(self, data):
        """
        Calculate basic technical indicators
        
        Parameters:
        data: Stock price data (pandas DataFrame)
        """
        try:
            if data.empty:
                return None
            
            indicators = {}
            
            # Moving averages
            indicators['SMA_20'] = data['Close'].rolling(window=20).mean()
            indicators['SMA_50'] = data['Close'].rolling(window=50).mean()
            indicators['EMA_12'] = data['Close'].ewm(span=12).mean()
            indicators['EMA_26'] = data['Close'].ewm(span=26).mean()
            
            # RSI
            delta = data['Close'].diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
            rs = gain / loss
            indicators['RSI'] = 100 - (100 / (1 + rs))
            
            # MACD
            indicators['MACD'] = indicators['EMA_12'] - indicators['EMA_26']
            indicators['MACD_Signal'] = indicators['MACD'].ewm(span=9).mean()
            indicators['MACD_Histogram'] = indicators['MACD'] - indicators['MACD_Signal']
            
            # Bollinger Bands
            indicators['BB_Middle'] = data['Close'].rolling(window=20).mean()
            bb_std = data['Close'].rolling(window=20).std()
            indicators['BB_Upper'] = indicators['BB_Middle'] + (bb_std * 2)
            indicators['BB_Lower'] = indicators['BB_Middle'] - (bb_std * 2)
            
            # Volume indicators
            indicators['Volume_SMA'] = data['Volume'].rolling(window=20).mean()
            indicators['Volume_Ratio'] = data['Volume'] / indicators['Volume_SMA']
            
            return indicators
            
        except Exception as e:
            print(f"Error calculating technical indicators: {e}")
            return None
    
    def get_sector_performance(self, sector_etfs=None):
        """
        Fetch sector performance data
        
        Parameters:
        sector_etfs: Dictionary of sector ETFs
        """
        try:
            if sector_etfs is None:
                sector_etfs = {
                    'Technology': 'XLK',
                    'Healthcare': 'XLV',
                    'Financial': 'XLF',
                    'Consumer Discretionary': 'XLY',
                    'Consumer Staples': 'XLP',
                    'Energy': 'XLE',
                    'Utilities': 'XLU',
                    'Industrials': 'XLI',
                    'Materials': 'XLB',
                    'Real Estate': 'XLRE',
                    'Communication': 'XLC'
                }
            
            sector_data = {}
            
            for sector, etf in sector_etfs.items():
                data = self.get_stock_data(etf, period='1y')
                if data is not None:
                    # Calculate performance metrics
                    current_price = data['Close'].iloc[-1]
                    year_ago_price = data['Close'].iloc[0]
                    ytd_return = (current_price / year_ago_price - 1) * 100
                    
                    sector_data[sector] = {
                        'symbol': etf,
                        'current_price': current_price,
                        'ytd_return': ytd_return,
                        'data': data
                    }
            
            return sector_data
            
        except Exception as e:
            print(f"Error fetching sector performance: {e}")
            return None
    
    def validate_symbol(self, symbol):
        """
        Validate if a symbol exists and has data
        
        Parameters:
        symbol: Stock symbol to validate
        """
        try:
            ticker = yf.Ticker(symbol)
            
            # Try to get basic info
            info = ticker.info
            
            # Check if we got meaningful data
            if 'symbol' in info or 'shortName' in info:
                return True
            else:
                return False
                
        except Exception as e:
            print(f"Error validating symbol {symbol}: {e}")
            return False
