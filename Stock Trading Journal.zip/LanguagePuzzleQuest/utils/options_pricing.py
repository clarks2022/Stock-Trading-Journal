import numpy as np
from scipy.stats import norm
import pandas as pd

class OptionsCalculator:
    """Options pricing and Greeks calculation using Black-Scholes model"""
    
    def __init__(self):
        pass
    
    def black_scholes(self, S, K, T, r, sigma, option_type='call'):
        """
        Calculate option price using Black-Scholes formula
        
        Parameters:
        S: Current stock price
        K: Strike price
        T: Time to expiration (in years)
        r: Risk-free rate
        sigma: Volatility
        option_type: 'call' or 'put'
        """
        try:
            # Handle edge cases
            if T <= 0:
                if option_type == 'call':
                    return max(S - K, 0)
                else:
                    return max(K - S, 0)
            
            # Calculate d1 and d2
            d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
            d2 = d1 - sigma * np.sqrt(T)
            
            if option_type == 'call':
                price = S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
            else:  # put
                price = K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
            
            return max(price, 0)
            
        except Exception as e:
            print(f"Error in Black-Scholes calculation: {e}")
            return 0
    
    def calculate_greeks(self, S, K, T, r, sigma, option_type='call'):
        """
        Calculate option Greeks
        
        Returns dictionary with Delta, Gamma, Theta, Vega, and Rho
        """
        try:
            if T <= 0:
                return {
                    'delta': 0,
                    'gamma': 0,
                    'theta': 0,
                    'vega': 0,
                    'rho': 0
                }
            
            # Calculate d1 and d2
            d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
            d2 = d1 - sigma * np.sqrt(T)
            
            # Delta
            if option_type == 'call':
                delta = norm.cdf(d1)
            else:  # put
                delta = norm.cdf(d1) - 1
            
            # Gamma (same for calls and puts)
            gamma = norm.pdf(d1) / (S * sigma * np.sqrt(T))
            
            # Theta
            theta_common = -(S * norm.pdf(d1) * sigma) / (2 * np.sqrt(T))
            if option_type == 'call':
                theta = theta_common - r * K * np.exp(-r * T) * norm.cdf(d2)
            else:  # put
                theta = theta_common + r * K * np.exp(-r * T) * norm.cdf(-d2)
            
            # Convert theta to per-day basis
            theta = theta / 365
            
            # Vega (same for calls and puts)
            vega = S * norm.pdf(d1) * np.sqrt(T) / 100  # Divide by 100 for 1% volatility change
            
            # Rho
            if option_type == 'call':
                rho = K * T * np.exp(-r * T) * norm.cdf(d2) / 100
            else:  # put
                rho = -K * T * np.exp(-r * T) * norm.cdf(-d2) / 100
            
            return {
                'delta': delta,
                'gamma': gamma,
                'theta': theta,
                'vega': vega,
                'rho': rho
            }
            
        except Exception as e:
            print(f"Error in Greeks calculation: {e}")
            return {
                'delta': 0,
                'gamma': 0,
                'theta': 0,
                'vega': 0,
                'rho': 0
            }
    
    def implied_volatility(self, S, K, T, r, market_price, option_type='call', max_iterations=100):
        """
        Calculate implied volatility using Newton-Raphson method
        """
        try:
            if T <= 0:
                return 0
            
            # Initial guess
            sigma = 0.2
            
            for i in range(max_iterations):
                # Calculate price and vega
                price = self.black_scholes(S, K, T, r, sigma, option_type)
                vega = self.calculate_greeks(S, K, T, r, sigma, option_type)['vega'] * 100
                
                # Check convergence
                price_diff = price - market_price
                if abs(price_diff) < 0.001:
                    return sigma
                
                # Newton-Raphson update
                if vega != 0:
                    sigma = sigma - price_diff / vega
                    sigma = max(0.001, min(sigma, 5.0))  # Keep sigma in reasonable bounds
                else:
                    break
            
            return sigma
            
        except Exception as e:
            print(f"Error in implied volatility calculation: {e}")
            return 0.2
    
    def option_payoff(self, S, K, premium, option_type='call'):
        """
        Calculate option payoff at expiration
        """
        if option_type == 'call':
            intrinsic_value = max(S - K, 0)
        else:  # put
            intrinsic_value = max(K - S, 0)
        
        return intrinsic_value - premium
    
    def calculate_breakeven(self, K, premium, option_type='call'):
        """
        Calculate breakeven price for option
        """
        if option_type == 'call':
            return K + premium
        else:  # put
            return K - premium
    
    def monte_carlo_option_price(self, S, K, T, r, sigma, option_type='call', simulations=10000):
        """
        Calculate option price using Monte Carlo simulation
        """
        try:
            dt = T
            nudt = (r - 0.5 * sigma ** 2) * dt
            sidt = sigma * np.sqrt(dt)
            
            # Generate random price paths
            Z = np.random.normal(0, 1, simulations)
            ST = S * np.exp(nudt + sidt * Z)
            
            # Calculate payoffs
            if option_type == 'call':
                payoffs = np.maximum(ST - K, 0)
            else:  # put
                payoffs = np.maximum(K - ST, 0)
            
            # Discount back to present value
            option_price = np.exp(-r * T) * np.mean(payoffs)
            
            return option_price
            
        except Exception as e:
            print(f"Error in Monte Carlo simulation: {e}")
            return 0
    
    def binomial_option_price(self, S, K, T, r, sigma, option_type='call', steps=100):
        """
        Calculate option price using binomial tree model
        """
        try:
            dt = T / steps
            u = np.exp(sigma * np.sqrt(dt))
            d = 1 / u
            p = (np.exp(r * dt) - d) / (u - d)
            
            # Initialize asset prices at maturity
            asset_prices = np.zeros(steps + 1)
            for i in range(steps + 1):
                asset_prices[i] = S * (u ** (steps - i)) * (d ** i)
            
            # Initialize option values at maturity
            option_values = np.zeros(steps + 1)
            for i in range(steps + 1):
                if option_type == 'call':
                    option_values[i] = max(asset_prices[i] - K, 0)
                else:  # put
                    option_values[i] = max(K - asset_prices[i], 0)
            
            # Step backwards through tree
            for j in range(steps - 1, -1, -1):
                for i in range(j + 1):
                    option_values[i] = (p * option_values[i] + (1 - p) * option_values[i + 1]) * np.exp(-r * dt)
            
            return option_values[0]
            
        except Exception as e:
            print(f"Error in binomial tree calculation: {e}")
            return 0
    
    def delta_hedging_simulation(self, S, K, T, r, sigma, option_type='call', steps=100):
        """
        Simulate delta hedging strategy
        """
        try:
            dt = T / steps
            hedge_portfolio = []
            
            current_price = S
            for i in range(steps):
                # Calculate current delta
                time_remaining = T - (i * dt)
                if time_remaining > 0:
                    greeks = self.calculate_greeks(current_price, K, time_remaining, r, sigma, option_type)
                    delta = greeks['delta']
                else:
                    delta = 0
                
                # Calculate option price
                option_price = self.black_scholes(current_price, K, time_remaining, r, sigma, option_type)
                
                hedge_portfolio.append({
                    'step': i,
                    'stock_price': current_price,
                    'option_price': option_price,
                    'delta': delta,
                    'time_remaining': time_remaining
                })
                
                # Simulate next price movement
                if i < steps - 1:
                    dW = np.random.normal(0, np.sqrt(dt))
                    current_price = current_price * np.exp((r - 0.5 * sigma ** 2) * dt + sigma * dW)
            
            return pd.DataFrame(hedge_portfolio)
            
        except Exception as e:
            print(f"Error in delta hedging simulation: {e}")
            return pd.DataFrame()
