import numpy as np
import pandas as pd
from scipy.stats import norm

class RiskManager:
    """Risk management utilities for portfolio and position analysis"""
    
    def __init__(self):
        pass
    
    def calculate_position_size(self, account_value, risk_per_trade, entry_price, stop_loss_price, method='fixed_percentage'):
        """
        Calculate position size based on risk management parameters
        
        Parameters:
        account_value: Total account value
        risk_per_trade: Risk per trade as percentage (e.g., 0.02 for 2%)
        entry_price: Entry price for the position
        stop_loss_price: Stop loss price
        method: 'fixed_percentage', 'kelly_criterion', or 'volatility_based'
        """
        try:
            risk_amount = account_value * risk_per_trade
            risk_per_share = abs(entry_price - stop_loss_price)
            
            if risk_per_share <= 0:
                return 0
            
            if method == 'fixed_percentage':
                position_size = risk_amount / risk_per_share
            elif method == 'kelly_criterion':
                # Simplified Kelly criterion (would need win rate and avg win/loss in practice)
                win_rate = 0.6  # Assumption
                avg_win = 0.08  # Assumption
                avg_loss = 0.04  # Assumption
                kelly_fraction = (win_rate * avg_win - (1 - win_rate) * avg_loss) / avg_win
                kelly_fraction = max(0, min(kelly_fraction, 0.25))  # Cap at 25%
                position_size = (account_value * kelly_fraction) / entry_price
            elif method == 'volatility_based':
                # Adjust position size based on volatility
                volatility = 0.2  # Assumption - would calculate from historical data
                volatility_adjustment = 0.2 / volatility  # Normalize to 20% volatility
                position_size = (risk_amount / risk_per_share) * volatility_adjustment
            
            return max(0, int(position_size))
            
        except Exception as e:
            print(f"Error calculating position size: {e}")
            return 0
    
    def calculate_var(self, returns, confidence_level=0.95):
        """
        Calculate Value at Risk (VaR)
        
        Parameters:
        returns: Series of returns
        confidence_level: Confidence level (e.g., 0.95 for 95%)
        """
        try:
            if len(returns) == 0:
                return 0
            
            # Historical VaR
            var_percentile = (1 - confidence_level) * 100
            historical_var = np.percentile(returns, var_percentile)
            
            # Parametric VaR (assuming normal distribution)
            mean_return = np.mean(returns)
            std_return = np.std(returns)
            z_score = norm.ppf(1 - confidence_level)
            parametric_var = mean_return + z_score * std_return
            
            return {
                'historical_var': historical_var,
                'parametric_var': parametric_var,
                'confidence_level': confidence_level
            }
            
        except Exception as e:
            print(f"Error calculating VaR: {e}")
            return {'historical_var': 0, 'parametric_var': 0, 'confidence_level': confidence_level}
    
    def calculate_expected_shortfall(self, returns, confidence_level=0.95):
        """
        Calculate Expected Shortfall (Conditional VaR)
        """
        try:
            if len(returns) == 0:
                return 0
            
            var_percentile = (1 - confidence_level) * 100
            var_threshold = np.percentile(returns, var_percentile)
            
            # Expected shortfall is the average of returns below VaR
            tail_returns = returns[returns <= var_threshold]
            expected_shortfall = np.mean(tail_returns) if len(tail_returns) > 0 else 0
            
            return expected_shortfall
            
        except Exception as e:
            print(f"Error calculating Expected Shortfall: {e}")
            return 0
    
    def calculate_maximum_drawdown(self, prices_or_returns, is_returns=False):
        """
        Calculate maximum drawdown
        
        Parameters:
        prices_or_returns: Price series or returns series
        is_returns: True if input is returns, False if prices
        """
        try:
            if is_returns:
                # Convert returns to cumulative value
                cumulative_returns = (1 + prices_or_returns).cumprod()
            else:
                cumulative_returns = prices_or_returns
            
            # Calculate running maximum
            peak = cumulative_returns.expanding().max()
            
            # Calculate drawdown
            drawdown = (cumulative_returns - peak) / peak
            
            # Maximum drawdown
            max_drawdown = drawdown.min()
            
            return {
                'max_drawdown': max_drawdown,
                'drawdown_series': drawdown
            }
            
        except Exception as e:
            print(f"Error calculating maximum drawdown: {e}")
            return {'max_drawdown': 0, 'drawdown_series': pd.Series()}
    
    def calculate_sharpe_ratio(self, returns, risk_free_rate=0.02):
        """
        Calculate Sharpe ratio
        
        Parameters:
        returns: Series of returns
        risk_free_rate: Risk-free rate (annual)
        """
        try:
            if len(returns) == 0:
                return 0
            
            # Annualize returns
            annual_returns = np.mean(returns) * 252
            annual_volatility = np.std(returns) * np.sqrt(252)
            
            if annual_volatility == 0:
                return 0
            
            sharpe_ratio = (annual_returns - risk_free_rate) / annual_volatility
            
            return sharpe_ratio
            
        except Exception as e:
            print(f"Error calculating Sharpe ratio: {e}")
            return 0
    
    def calculate_sortino_ratio(self, returns, risk_free_rate=0.02):
        """
        Calculate Sortino ratio (uses downside deviation instead of total volatility)
        """
        try:
            if len(returns) == 0:
                return 0
            
            # Annualize returns
            annual_returns = np.mean(returns) * 252
            
            # Calculate downside deviation
            downside_returns = returns[returns < 0]
            if len(downside_returns) == 0:
                return float('inf')
            
            downside_deviation = np.std(downside_returns) * np.sqrt(252)
            
            if downside_deviation == 0:
                return float('inf')
            
            sortino_ratio = (annual_returns - risk_free_rate) / downside_deviation
            
            return sortino_ratio
            
        except Exception as e:
            print(f"Error calculating Sortino ratio: {e}")
            return 0
    
    def calculate_portfolio_beta(self, portfolio_returns, market_returns):
        """
        Calculate portfolio beta relative to market
        """
        try:
            if len(portfolio_returns) == 0 or len(market_returns) == 0:
                return 0
            
            # Align data
            aligned_data = pd.concat([portfolio_returns, market_returns], axis=1).dropna()
            
            if len(aligned_data) < 2:
                return 0
            
            portfolio_aligned = aligned_data.iloc[:, 0]
            market_aligned = aligned_data.iloc[:, 1]
            
            # Calculate covariance and variance
            covariance = np.cov(portfolio_aligned, market_aligned)[0, 1]
            market_variance = np.var(market_aligned)
            
            if market_variance == 0:
                return 0
            
            beta = covariance / market_variance
            
            return beta
            
        except Exception as e:
            print(f"Error calculating portfolio beta: {e}")
            return 0
    
    def calculate_correlation_matrix(self, returns_df):
        """
        Calculate correlation matrix for portfolio positions
        """
        try:
            if returns_df.empty:
                return pd.DataFrame()
            
            correlation_matrix = returns_df.corr()
            
            return correlation_matrix
            
        except Exception as e:
            print(f"Error calculating correlation matrix: {e}")
            return pd.DataFrame()
    
    def assess_concentration_risk(self, portfolio_weights, max_weight_threshold=0.1):
        """
        Assess portfolio concentration risk
        
        Parameters:
        portfolio_weights: Dictionary or Series of position weights
        max_weight_threshold: Maximum allowable weight for single position
        """
        try:
            if isinstance(portfolio_weights, dict):
                weights = pd.Series(portfolio_weights)
            else:
                weights = portfolio_weights
            
            # Concentration metrics
            max_weight = weights.max()
            top_5_concentration = weights.nlargest(5).sum()
            herfindahl_index = (weights ** 2).sum()
            
            # Risk assessment
            concentration_risk = {
                'max_weight': max_weight,
                'top_5_concentration': top_5_concentration,
                'herfindahl_index': herfindahl_index,
                'num_positions': len(weights),
                'diversification_ratio': 1 / herfindahl_index if herfindahl_index > 0 else 0
            }
            
            # Risk flags
            concentration_risk['high_concentration'] = max_weight > max_weight_threshold
            concentration_risk['excessive_top_5'] = top_5_concentration > 0.5
            
            return concentration_risk
            
        except Exception as e:
            print(f"Error assessing concentration risk: {e}")
            return {}
    
    def calculate_risk_adjusted_return(self, returns, method='sharpe'):
        """
        Calculate risk-adjusted returns using various methods
        """
        try:
            if len(returns) == 0:
                return 0
            
            if method == 'sharpe':
                return self.calculate_sharpe_ratio(returns)
            elif method == 'sortino':
                return self.calculate_sortino_ratio(returns)
            elif method == 'calmar':
                annual_return = np.mean(returns) * 252
                max_dd = self.calculate_maximum_drawdown(returns, is_returns=True)['max_drawdown']
                return annual_return / abs(max_dd) if max_dd != 0 else 0
            else:
                return self.calculate_sharpe_ratio(returns)
                
        except Exception as e:
            print(f"Error calculating risk-adjusted return: {e}")
            return 0
    
    def generate_risk_report(self, returns, portfolio_weights=None, benchmark_returns=None):
        """
        Generate comprehensive risk report
        """
        try:
            risk_report = {}
            
            # Basic statistics
            risk_report['total_return'] = (1 + returns).prod() - 1
            risk_report['annualized_return'] = np.mean(returns) * 252
            risk_report['volatility'] = np.std(returns) * np.sqrt(252)
            
            # Risk metrics
            risk_report['var'] = self.calculate_var(returns)
            risk_report['expected_shortfall'] = self.calculate_expected_shortfall(returns)
            risk_report['maximum_drawdown'] = self.calculate_maximum_drawdown(returns, is_returns=True)
            
            # Risk-adjusted returns
            risk_report['sharpe_ratio'] = self.calculate_sharpe_ratio(returns)
            risk_report['sortino_ratio'] = self.calculate_sortino_ratio(returns)
            
            # Portfolio-specific metrics
            if portfolio_weights is not None:
                risk_report['concentration_risk'] = self.assess_concentration_risk(portfolio_weights)
            
            # Benchmark comparison
            if benchmark_returns is not None:
                risk_report['beta'] = self.calculate_portfolio_beta(returns, benchmark_returns)
                
                # Information ratio
                active_returns = returns - benchmark_returns
                tracking_error = np.std(active_returns) * np.sqrt(252)
                risk_report['information_ratio'] = (np.mean(active_returns) * 252) / tracking_error if tracking_error > 0 else 0
            
            return risk_report
            
        except Exception as e:
            print(f"Error generating risk report: {e}")
            return {}
    
    def calculate_portfolio_var(self, weights, returns_df, confidence_level=0.95):
        """
        Calculate portfolio VaR considering correlations
        """
        try:
            if returns_df.empty or len(weights) == 0:
                return 0
            
            # Calculate portfolio returns
            portfolio_returns = (returns_df * weights).sum(axis=1)
            
            # Calculate VaR
            var_result = self.calculate_var(portfolio_returns, confidence_level)
            
            return var_result
            
        except Exception as e:
            print(f"Error calculating portfolio VaR: {e}")
            return {'historical_var': 0, 'parametric_var': 0, 'confidence_level': confidence_level}
    
    def stress_test_portfolio(self, weights, returns_df, stress_scenarios):
        """
        Perform stress testing on portfolio
        
        Parameters:
        weights: Portfolio weights
        returns_df: Historical returns dataframe
        stress_scenarios: Dictionary of stress scenarios
        """
        try:
            stress_results = {}
            
            for scenario_name, scenario in stress_scenarios.items():
                # Apply stress scenario to returns
                stressed_returns = returns_df.copy()
                
                for asset, stress_factor in scenario.items():
                    if asset in stressed_returns.columns:
                        stressed_returns[asset] = stressed_returns[asset] * stress_factor
                
                # Calculate stressed portfolio returns
                stressed_portfolio_returns = (stressed_returns * weights).sum(axis=1)
                
                # Calculate metrics under stress
                stress_results[scenario_name] = {
                    'portfolio_return': np.mean(stressed_portfolio_returns) * 252,
                    'portfolio_volatility': np.std(stressed_portfolio_returns) * np.sqrt(252),
                    'max_drawdown': self.calculate_maximum_drawdown(stressed_portfolio_returns, is_returns=True)['max_drawdown'],
                    'var_95': self.calculate_var(stressed_portfolio_returns, 0.95)['historical_var']
                }
            
            return stress_results
            
        except Exception as e:
            print(f"Error in stress testing: {e}")
            return {}
