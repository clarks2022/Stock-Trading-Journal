import pandas as pd
import numpy as np
from scipy.signal import find_peaks

class TechnicalIndicators:
    """Technical indicators calculation class for stock analysis"""
    
    def __init__(self):
        pass
    
    def sma(self, data, window):
        """
        Simple Moving Average
        
        Parameters:
        data: Price data (pandas Series)
        window: Period for moving average
        """
        try:
            return data.rolling(window=window).mean()
        except Exception as e:
            print(f"Error calculating SMA: {e}")
            return pd.Series(index=data.index, dtype=float)
    
    def ema(self, data, window):
        """
        Exponential Moving Average
        
        Parameters:
        data: Price data (pandas Series)
        window: Period for moving average
        """
        try:
            return data.ewm(span=window, adjust=False).mean()
        except Exception as e:
            print(f"Error calculating EMA: {e}")
            return pd.Series(index=data.index, dtype=float)
    
    def rsi(self, data, window=14):
        """
        Relative Strength Index
        
        Parameters:
        data: Price data (pandas Series)
        window: Period for RSI calculation (default 14)
        """
        try:
            delta = data.diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
            
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs))
            
            return rsi
        except Exception as e:
            print(f"Error calculating RSI: {e}")
            return pd.Series(index=data.index, dtype=float)
    
    def macd(self, data, fast=12, slow=26, signal=9):
        """
        Moving Average Convergence Divergence
        
        Parameters:
        data: Price data (pandas Series)
        fast: Fast EMA period (default 12)
        slow: Slow EMA period (default 26)
        signal: Signal line EMA period (default 9)
        """
        try:
            ema_fast = self.ema(data, fast)
            ema_slow = self.ema(data, slow)
            
            macd_line = ema_fast - ema_slow
            signal_line = self.ema(macd_line, signal)
            histogram = macd_line - signal_line
            
            return {
                'macd': macd_line,
                'signal': signal_line,
                'histogram': histogram
            }
        except Exception as e:
            print(f"Error calculating MACD: {e}")
            return {
                'macd': pd.Series(index=data.index, dtype=float),
                'signal': pd.Series(index=data.index, dtype=float),
                'histogram': pd.Series(index=data.index, dtype=float)
            }
    
    def bollinger_bands(self, data, window=20, std_dev=2):
        """
        Bollinger Bands
        
        Parameters:
        data: Price data (pandas Series)
        window: Period for moving average (default 20)
        std_dev: Standard deviation multiplier (default 2)
        """
        try:
            middle = self.sma(data, window)
            std = data.rolling(window=window).std()
            
            upper = middle + (std * std_dev)
            lower = middle - (std * std_dev)
            
            return {
                'upper': upper,
                'middle': middle,
                'lower': lower
            }
        except Exception as e:
            print(f"Error calculating Bollinger Bands: {e}")
            return {
                'upper': pd.Series(index=data.index, dtype=float),
                'middle': pd.Series(index=data.index, dtype=float),
                'lower': pd.Series(index=data.index, dtype=float)
            }
    
    def stochastic_oscillator(self, high, low, close, k_period=14, d_period=3):
        """
        Stochastic Oscillator
        
        Parameters:
        high: High price data (pandas Series)
        low: Low price data (pandas Series)
        close: Close price data (pandas Series)
        k_period: %K period (default 14)
        d_period: %D period (default 3)
        """
        try:
            lowest_low = low.rolling(window=k_period).min()
            highest_high = high.rolling(window=k_period).max()
            
            k_percent = 100 * ((close - lowest_low) / (highest_high - lowest_low))
            d_percent = k_percent.rolling(window=d_period).mean()
            
            return {
                'k_percent': k_percent,
                'd_percent': d_percent
            }
        except Exception as e:
            print(f"Error calculating Stochastic Oscillator: {e}")
            return {
                'k_percent': pd.Series(index=close.index, dtype=float),
                'd_percent': pd.Series(index=close.index, dtype=float)
            }
    
    def williams_r(self, high, low, close, period=14):
        """
        Williams %R
        
        Parameters:
        high: High price data (pandas Series)
        low: Low price data (pandas Series)
        close: Close price data (pandas Series)
        period: Period for calculation (default 14)
        """
        try:
            highest_high = high.rolling(window=period).max()
            lowest_low = low.rolling(window=period).min()
            
            wr = -100 * ((highest_high - close) / (highest_high - lowest_low))
            
            return wr
        except Exception as e:
            print(f"Error calculating Williams %R: {e}")
            return pd.Series(index=close.index, dtype=float)
    
    def atr(self, data, period=14):
        """
        Average True Range
        
        Parameters:
        data: OHLC data (pandas DataFrame)
        period: Period for ATR calculation (default 14)
        """
        try:
            high = data['High']
            low = data['Low']
            close = data['Close']
            
            # Calculate True Range
            tr1 = high - low
            tr2 = abs(high - close.shift())
            tr3 = abs(low - close.shift())
            
            true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
            
            # Calculate ATR
            atr = true_range.rolling(window=period).mean()
            
            return atr
        except Exception as e:
            print(f"Error calculating ATR: {e}")
            return pd.Series(index=data.index, dtype=float)
    
    def cci(self, high, low, close, period=20):
        """
        Commodity Channel Index
        
        Parameters:
        high: High price data (pandas Series)
        low: Low price data (pandas Series)
        close: Close price data (pandas Series)
        period: Period for CCI calculation (default 20)
        """
        try:
            typical_price = (high + low + close) / 3
            sma_tp = typical_price.rolling(window=period).mean()
            
            # Calculate mean deviation
            mean_deviation = typical_price.rolling(window=period).apply(
                lambda x: np.mean(np.abs(x - x.mean())), raw=True
            )
            
            cci = (typical_price - sma_tp) / (0.015 * mean_deviation)
            
            return cci
        except Exception as e:
            print(f"Error calculating CCI: {e}")
            return pd.Series(index=close.index, dtype=float)
    
    def adx(self, high, low, close, period=14):
        """
        Average Directional Index
        
        Parameters:
        high: High price data (pandas Series)
        low: Low price data (pandas Series)
        close: Close price data (pandas Series)
        period: Period for ADX calculation (default 14)
        """
        try:
            # Calculate True Range
            tr = self.atr(pd.DataFrame({'High': high, 'Low': low, 'Close': close}), period=1)
            
            # Calculate Directional Movement
            plus_dm = high.diff()
            minus_dm = -low.diff()
            
            plus_dm[plus_dm < 0] = 0
            minus_dm[minus_dm < 0] = 0
            
            # Smooth the values
            plus_dm_smooth = plus_dm.rolling(window=period).mean()
            minus_dm_smooth = minus_dm.rolling(window=period).mean()
            tr_smooth = tr.rolling(window=period).mean()
            
            # Calculate DI+ and DI-
            plus_di = 100 * (plus_dm_smooth / tr_smooth)
            minus_di = 100 * (minus_dm_smooth / tr_smooth)
            
            # Calculate DX
            dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
            
            # Calculate ADX
            adx = dx.rolling(window=period).mean()
            
            return {
                'adx': adx,
                'plus_di': plus_di,
                'minus_di': minus_di
            }
        except Exception as e:
            print(f"Error calculating ADX: {e}")
            return {
                'adx': pd.Series(index=close.index, dtype=float),
                'plus_di': pd.Series(index=close.index, dtype=float),
                'minus_di': pd.Series(index=close.index, dtype=float)
            }
    
    def momentum(self, data, period=10):
        """
        Momentum indicator
        
        Parameters:
        data: Price data (pandas Series)
        period: Period for momentum calculation (default 10)
        """
        try:
            momentum = data.diff(period)
            return momentum
        except Exception as e:
            print(f"Error calculating Momentum: {e}")
            return pd.Series(index=data.index, dtype=float)
    
    def rate_of_change(self, data, period=10):
        """
        Rate of Change
        
        Parameters:
        data: Price data (pandas Series)
        period: Period for ROC calculation (default 10)
        """
        try:
            roc = ((data - data.shift(period)) / data.shift(period)) * 100
            return roc
        except Exception as e:
            print(f"Error calculating ROC: {e}")
            return pd.Series(index=data.index, dtype=float)
    
    def obv(self, close, volume):
        """
        On-Balance Volume
        
        Parameters:
        close: Close price data (pandas Series)
        volume: Volume data (pandas Series)
        """
        try:
            obv = pd.Series(index=close.index, dtype=float)
            obv.iloc[0] = 0
            
            for i in range(1, len(close)):
                if close.iloc[i] > close.iloc[i-1]:
                    obv.iloc[i] = obv.iloc[i-1] + volume.iloc[i]
                elif close.iloc[i] < close.iloc[i-1]:
                    obv.iloc[i] = obv.iloc[i-1] - volume.iloc[i]
                else:
                    obv.iloc[i] = obv.iloc[i-1]
            
            return obv
        except Exception as e:
            print(f"Error calculating OBV: {e}")
            return pd.Series(index=close.index, dtype=float)
    
    def vwap(self, high, low, close, volume):
        """
        Volume Weighted Average Price
        
        Parameters:
        high: High price data (pandas Series)
        low: Low price data (pandas Series)
        close: Close price data (pandas Series)
        volume: Volume data (pandas Series)
        """
        try:
            typical_price = (high + low + close) / 3
            cumulative_volume = volume.cumsum()
            cumulative_price_volume = (typical_price * volume).cumsum()
            
            vwap = cumulative_price_volume / cumulative_volume
            
            return vwap
        except Exception as e:
            print(f"Error calculating VWAP: {e}")
            return pd.Series(index=close.index, dtype=float)
    
    def parabolic_sar(self, high, low, close, af_start=0.02, af_increment=0.02, af_max=0.2):
        """
        Parabolic SAR
        
        Parameters:
        high: High price data (pandas Series)
        low: Low price data (pandas Series)
        close: Close price data (pandas Series)
        af_start: Starting acceleration factor (default 0.02)
        af_increment: AF increment (default 0.02)
        af_max: Maximum AF (default 0.2)
        """
        try:
            length = len(high)
            psar = pd.Series(index=high.index, dtype=float)
            
            # Initialize
            psar.iloc[0] = low.iloc[0]
            bull = True
            af = af_start
            ep = high.iloc[0]
            
            for i in range(1, length):
                if bull:
                    psar.iloc[i] = psar.iloc[i-1] + af * (ep - psar.iloc[i-1])
                    
                    if low.iloc[i] <= psar.iloc[i]:
                        bull = False
                        psar.iloc[i] = ep
                        af = af_start
                        ep = low.iloc[i]
                    else:
                        if high.iloc[i] > ep:
                            ep = high.iloc[i]
                            af = min(af + af_increment, af_max)
                else:
                    psar.iloc[i] = psar.iloc[i-1] - af * (psar.iloc[i-1] - ep)
                    
                    if high.iloc[i] >= psar.iloc[i]:
                        bull = True
                        psar.iloc[i] = ep
                        af = af_start
                        ep = high.iloc[i]
                    else:
                        if low.iloc[i] < ep:
                            ep = low.iloc[i]
                            af = min(af + af_increment, af_max)
            
            return psar
        except Exception as e:
            print(f"Error calculating Parabolic SAR: {e}")
            return pd.Series(index=high.index, dtype=float)
    
    def ichimoku_cloud(self, high, low, close, tenkan_period=9, kijun_period=26, senkou_span_b_period=52):
        """
        Ichimoku Cloud
        
        Parameters:
        high: High price data (pandas Series)
        low: Low price data (pandas Series)
        close: Close price data (pandas Series)
        tenkan_period: Tenkan-sen period (default 9)
        kijun_period: Kijun-sen period (default 26)
        senkou_span_b_period: Senkou Span B period (default 52)
        """
        try:
            # Tenkan-sen (Conversion Line)
            tenkan_sen = (high.rolling(window=tenkan_period).max() + 
                         low.rolling(window=tenkan_period).min()) / 2
            
            # Kijun-sen (Base Line)
            kijun_sen = (high.rolling(window=kijun_period).max() + 
                        low.rolling(window=kijun_period).min()) / 2
            
            # Senkou Span A (Leading Span A)
            senkou_span_a = ((tenkan_sen + kijun_sen) / 2).shift(kijun_period)
            
            # Senkou Span B (Leading Span B)
            senkou_span_b = ((high.rolling(window=senkou_span_b_period).max() + 
                             low.rolling(window=senkou_span_b_period).min()) / 2).shift(kijun_period)
            
            # Chikou Span (Lagging Span)
            chikou_span = close.shift(-kijun_period)
            
            return {
                'tenkan_sen': tenkan_sen,
                'kijun_sen': kijun_sen,
                'senkou_span_a': senkou_span_a,
                'senkou_span_b': senkou_span_b,
                'chikou_span': chikou_span
            }
        except Exception as e:
            print(f"Error calculating Ichimoku Cloud: {e}")
            return {
                'tenkan_sen': pd.Series(index=close.index, dtype=float),
                'kijun_sen': pd.Series(index=close.index, dtype=float),
                'senkou_span_a': pd.Series(index=close.index, dtype=float),
                'senkou_span_b': pd.Series(index=close.index, dtype=float),
                'chikou_span': pd.Series(index=close.index, dtype=float)
            }
    
    def fibonacci_retracement(self, high_price, low_price):
        """
        Fibonacci Retracement Levels
        
        Parameters:
        high_price: High price for retracement calculation
        low_price: Low price for retracement calculation
        """
        try:
            diff = high_price - low_price
            
            levels = {
                '0.0%': high_price,
                '23.6%': high_price - 0.236 * diff,
                '38.2%': high_price - 0.382 * diff,
                '50.0%': high_price - 0.5 * diff,
                '61.8%': high_price - 0.618 * diff,
                '78.6%': high_price - 0.786 * diff,
                '100.0%': low_price
            }
            
            return levels
        except Exception as e:
            print(f"Error calculating Fibonacci Retracement: {e}")
            return {}
    
    def detect_support_resistance(self, data, window=5):
        """
        Detect support and resistance levels
        
        Parameters:
        data: Price data (pandas Series)
        window: Window for peak/valley detection (default 5)
        """
        try:
            # Find peaks (resistance) and valleys (support)
            peaks, _ = find_peaks(data.values, distance=window)
            valleys, _ = find_peaks(-data.values, distance=window)
            
            resistance_levels = data.iloc[peaks].values
            support_levels = data.iloc[valleys].values
            
            return {
                'resistance': resistance_levels,
                'support': support_levels,
                'resistance_indices': peaks,
                'support_indices': valleys
            }
        except Exception as e:
            print(f"Error detecting support/resistance: {e}")
            return {
                'resistance': np.array([]),
                'support': np.array([]),
                'resistance_indices': np.array([]),
                'support_indices': np.array([])
            }
    
    def calculate_pivot_points(self, high, low, close):
        """
        Calculate Pivot Points
        
        Parameters:
        high: Previous day's high
        low: Previous day's low
        close: Previous day's close
        """
        try:
            pivot = (high + low + close) / 3
            
            # Support levels
            s1 = 2 * pivot - high
            s2 = pivot - (high - low)
            s3 = low - 2 * (high - pivot)
            
            # Resistance levels
            r1 = 2 * pivot - low
            r2 = pivot + (high - low)
            r3 = high + 2 * (pivot - low)
            
            return {
                'pivot': pivot,
                'r1': r1,
                'r2': r2,
                'r3': r3,
                's1': s1,
                's2': s2,
                's3': s3
            }
        except Exception as e:
            print(f"Error calculating Pivot Points: {e}")
            return {}
    
    def calculate_volatility(self, data, window=20):
        """
        Calculate historical volatility
        
        Parameters:
        data: Price data (pandas Series)
        window: Window for volatility calculation (default 20)
        """
        try:
            returns = data.pct_change()
            volatility = returns.rolling(window=window).std() * np.sqrt(252)  # Annualized
            
            return volatility
        except Exception as e:
            print(f"Error calculating volatility: {e}")
            return pd.Series(index=data.index, dtype=float)
    
    def calculate_correlation(self, data1, data2, window=20):
        """
        Calculate rolling correlation between two price series
        
        Parameters:
        data1: First price series
        data2: Second price series
        window: Window for correlation calculation (default 20)
        """
        try:
            correlation = data1.rolling(window=window).corr(data2)
            return correlation
        except Exception as e:
            print(f"Error calculating correlation: {e}")
            return pd.Series(index=data1.index, dtype=float)
